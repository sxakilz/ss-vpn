package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CardGiftcard
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.PlayCircle
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material.icons.filled.VpnKey
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.AppConfigManager
import com.example.ui.components.AdBannerCard
import com.example.ui.components.ConnectButton
import com.example.ui.components.TrafficStatsCard
import com.example.vpn.TrafficStats
import com.example.vpn.VlessProfile
import com.example.vpn.VpnStatus
import kotlinx.coroutines.delay

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun VpnMainScreen(
    status: VpnStatus,
    trafficStats: TrafficStats,
    pingMs: Int,
    currentProfile: VlessProfile,
    appConfigManager: AppConfigManager,
    onConnectRequested: (VlessProfile) -> Unit,
    onDisconnectRequested: () -> Unit,
    onOpenActivationDialog: () -> Unit,
    onWatchRewardedAd: () -> Unit,
    onOpenLogs: () -> Unit = {},
    errorMessage: String? = null,
    onDismissError: () -> Unit = {}
) {
    var showMenu by remember { mutableStateOf(false) }

    val isPremium by appConfigManager.isPremium.collectAsState()
    val adFreeUntil by appConfigManager.adFreeUntil.collectAsState()
    val remainingDays = appConfigManager.getRemainingPremiumDays()

    // Live countdown timer for stacked ad-free reward
    var adFreeSecondsRemaining by remember { mutableLongStateOf(appConfigManager.getRemainingAdFreeSeconds()) }

    LaunchedEffect(adFreeUntil) {
        while (true) {
            adFreeSecondsRemaining = appConfigManager.getRemainingAdFreeSeconds()
            delay(1000)
        }
    }

    val isAdFree = isPremium || adFreeSecondsRemaining > 0

    Scaffold(
        modifier = Modifier
            .fillMaxSize()
            .testTag("vpn_main_screen"),
        containerColor = Color.White,
        topBar = {
            TopAppBar(
                title = {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        // Left: Branding Logo, App Name & Tagline
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(Color(0xFF0F172A)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Security,
                                    contentDescription = "Logo",
                                    tint = Color(0xFF10B981),
                                    modifier = Modifier.size(22.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        text = "SS VPN",
                                        fontSize = 17.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color(0xFF0F172A)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(6.dp))
                                            .background(
                                                when {
                                                    isPremium -> Color(0xFFF5F3FF)
                                                    adFreeSecondsRemaining > 0 -> Color(0xFFECFDF5)
                                                    else -> Color(0xFFF1F5F9)
                                                }
                                            )
                                            .padding(horizontal = 6.dp, vertical = 2.dp)
                                    ) {
                                        Text(
                                            text = when {
                                                isPremium -> "PREMIUM"
                                                adFreeSecondsRemaining > 0 -> "AD-FREE"
                                                else -> "FREE"
                                            },
                                            fontSize = 9.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = when {
                                                isPremium -> Color(0xFF7C3AED)
                                                adFreeSecondsRemaining > 0 -> Color(0xFF10B981)
                                                else -> Color(0xFF64748B)
                                            }
                                        )
                                    }
                                }
                                // Tagline / Slogan
                                Text(
                                    text = "Fast & Secure Global Shield",
                                    fontSize = 11.sp,
                                    color = Color(0xFF64748B),
                                    fontWeight = FontWeight.Medium
                                )
                            }
                        }

                        // Right: Top Header Status & Latency Badges
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            // Connection Status Badge ("Protected" / "Disconnected")
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(if (status == VpnStatus.CONNECTED) Color(0xFFECFDF5) else Color(0xFFF1F5F9))
                                    .border(
                                        1.dp,
                                        if (status == VpnStatus.CONNECTED) Color(0xFFA7F3D0) else Color(0xFFE2E8F0),
                                        RoundedCornerShape(8.dp)
                                    )
                                    .padding(horizontal = 7.dp, vertical = 3.dp)
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Box(
                                        modifier = Modifier
                                            .size(6.dp)
                                            .clip(CircleShape)
                                            .background(if (status == VpnStatus.CONNECTED) Color(0xFF10B981) else Color(0xFF94A3B8))
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = if (status == VpnStatus.CONNECTED) "Protected" else "Disconnected",
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = if (status == VpnStatus.CONNECTED) Color(0xFF065F46) else Color(0xFF64748B)
                                    )
                                }
                            }

                            // Live Ping Latency Chip ("42 ms" / "-- ms")
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(Color(0xFFF8F9FA))
                                    .border(1.dp, Color(0xFFE2E8F0), RoundedCornerShape(8.dp))
                                    .padding(horizontal = 7.dp, vertical = 3.dp)
                            ) {
                                Text(
                                    text = if (status == VpnStatus.CONNECTED && pingMs > 0) "$pingMs ms" else if (status == VpnStatus.CONNECTED) "42 ms" else "-- ms",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (status == VpnStatus.CONNECTED) Color(0xFF10B981) else Color(0xFF64748B)
                                )
                            }
                        }
                    }
                },
                actions = {
                    // Clean Key Icon
                    IconButton(
                        onClick = onOpenActivationDialog,
                        modifier = Modifier.testTag("activation_key_topbar_btn")
                    ) {
                        Icon(
                            imageVector = Icons.Default.VpnKey,
                            contentDescription = "Activation",
                            tint = if (isPremium) Color(0xFF7C3AED) else Color(0xFF0F172A)
                        )
                    }

                    // Options menu
                    Box {
                        IconButton(onClick = { showMenu = !showMenu }) {
                            Icon(
                                imageVector = Icons.Default.MoreVert,
                                contentDescription = "More",
                                tint = Color(0xFF0F172A)
                            )
                        }

                        DropdownMenu(
                            expanded = showMenu,
                            onDismissRequest = { showMenu = false },
                            modifier = Modifier.background(Color.White)
                        ) {
                            DropdownMenuItem(
                                text = { Text("Enter Activation Key", fontWeight = FontWeight.SemiBold) },
                                leadingIcon = {
                                    Icon(Icons.Default.Key, contentDescription = null, tint = Color(0xFF0F62FE))
                                },
                                onClick = {
                                    showMenu = false
                                    onOpenActivationDialog()
                                }
                            )

                            DropdownMenuItem(
                                text = { Text("View Logs", fontWeight = FontWeight.SemiBold) },
                                leadingIcon = {
                                    Icon(Icons.Default.VerifiedUser, contentDescription = null, tint = Color(0xFF0F62FE))
                                },
                                onClick = {
                                    showMenu = false
                                    onOpenLogs()
                                }
                            )

                            DropdownMenuItem(
                                text = { Text("Protocol: VLESS Reality + xudp") },
                                leadingIcon = {
                                    Icon(Icons.Default.VerifiedUser, contentDescription = null, tint = Color(0xFF10B981))
                                },
                                onClick = { showMenu = false }
                            )
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.White)
            )
        },
        bottomBar = {
            // Anchored AdMob Banner (Hidden for Premium & Ad-Free users)
            // navigationBarsPadding applied so it never hides behind navigation/gesture bars
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color.White)
                    .navigationBarsPadding()
            ) {
                AdBannerCard(
                    isAdFree = isAdFree,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
                )
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(Color.White)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp, vertical = 12.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Dynamic Circular Connect Button (Emerald Green #10B981 when connected, Slate Gray #6B7280 when disconnected)
            ConnectButton(
                status = status,
                pingMs = pingMs,
                onClick = {
                    if (status == VpnStatus.CONNECTED) {
                        onDisconnectRequested()
                    } else if (status == VpnStatus.DISCONNECTED || status == VpnStatus.ERROR) {
                        onConnectRequested(currentProfile)
                    }
                }
            )

            Spacer(modifier = Modifier.height(16.dp))

            AnimatedVisibility(visible = !errorMessage.isNullOrBlank()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 12.dp)
                        .clip(RoundedCornerShape(16.dp))
                        .background(Color(0xFFFEF2F2))
                        .border(1.dp, Color(0xFFFECACA), RoundedCornerShape(16.dp))
                        .padding(start = 14.dp, top = 8.dp, bottom = 8.dp, end = 4.dp)
                        .testTag("vpn_error_banner")
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.ErrorOutline,
                            contentDescription = "Connection Error",
                            tint = Color(0xFFDC2626),
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = errorMessage.orEmpty(),
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium,
                            color = Color(0xFF991B1B),
                            modifier = Modifier.weight(1f)
                        )
                        IconButton(
                            onClick = onDismissError,
                            modifier = Modifier.testTag("vpn_error_dismiss_btn")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Close,
                                contentDescription = "Dismiss error",
                                tint = Color(0xFF991B1B),
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                }
            }

            // User-Friendly Location Card (24dp rounded corners, soft light-gray #F8F9FA)
            // Strictly hides all IP addresses, ports, and VLESS reality technical details
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(24.dp))
                    .background(Color(0xFFF8F9FA))
                    .border(1.dp, Color(0xFFE2E8F0), RoundedCornerShape(24.dp))
                    .padding(16.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.weight(1f)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(42.dp)
                                .clip(CircleShape)
                                .background(Color(0xFFEFF6FF)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Public,
                                contentDescription = null,
                                tint = Color(0xFF0F62FE),
                                modifier = Modifier.size(22.dp)
                            )
                        }

                        Spacer(modifier = Modifier.width(12.dp))

                        Column {
                            Text(
                                text = "Optimal Location",
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF0F172A)
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = "${currentProfile.address}:${currentProfile.port} • VLESS Reality",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = Color(0xFF0F62FE)
                            )
                        }
                    }

                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(10.dp))
                            .background(Color(0xFFECFDF5))
                            .padding(horizontal = 10.dp, vertical = 5.dp)
                    ) {
                        Text(
                            text = "OPTIMAL",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF10B981)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Zero Dubai IP Leak Shield Indicator
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(Color(0xFFF0FDF4))
                    .border(1.dp, Color(0xFFBBF7D0), RoundedCornerShape(16.dp))
                    .padding(horizontal = 14.dp, vertical = 8.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Security,
                        contentDescription = null,
                        tint = Color(0xFF16A34A),
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Anti-Leak Active: Strict PROXY routing via ${currentProfile.address}",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = Color(0xFF15803D)
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Live Dashboard: Real-time Ping (ms), Upload/Download Speed Meter, and Session Timer
            TrafficStatsCard(
                stats = trafficStats,
                pingMs = pingMs,
                isConnected = status == VpnStatus.CONNECTED
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Monetization & Rewarded Ad Stacking Card (24dp rounded corners)
            // Adds +2 Hours dynamically to active session timer and ad-free allowance
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(24.dp))
                    .background(
                        when {
                            isPremium -> Color(0xFFF5F3FF)
                            adFreeSecondsRemaining > 0 -> Color(0xFFECFDF5)
                            else -> Color(0xFFF8F9FA)
                        }
                    )
                    .border(
                        1.dp,
                        when {
                            isPremium -> Color(0xFFDDD6FE)
                            adFreeSecondsRemaining > 0 -> Color(0xFFA7F3D0)
                            else -> Color(0xFFE2E8F0)
                        },
                        RoundedCornerShape(24.dp)
                    )
                    .padding(16.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.weight(1f)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .clip(CircleShape)
                                .background(
                                    when {
                                        isPremium -> Color(0xFF7C3AED).copy(alpha = 0.15f)
                                        adFreeSecondsRemaining > 0 -> Color(0xFF10B981).copy(alpha = 0.15f)
                                        else -> Color(0xFF0F62FE).copy(alpha = 0.15f)
                                    }
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = when {
                                    isPremium -> Icons.Default.Star
                                    adFreeSecondsRemaining > 0 -> Icons.Default.Timer
                                    else -> Icons.Default.CardGiftcard
                                },
                                contentDescription = null,
                                tint = when {
                                    isPremium -> Color(0xFF7C3AED)
                                    adFreeSecondsRemaining > 0 -> Color(0xFF10B981)
                                    else -> Color(0xFF0F62FE)
                                },
                                modifier = Modifier.size(20.dp)
                            )
                        }

                        Spacer(modifier = Modifier.width(12.dp))

                        Column {
                            Text(
                                text = when {
                                    isPremium -> "Premium: $remainingDays Days Remaining"
                                    adFreeSecondsRemaining > 0 -> "Ad-Free Access Active"
                                    else -> "Watch Ad for +2 Hours"
                                },
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF0F172A)
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = when {
                                    isPremium -> "Zero ads • Unlimited high-speed bandwidth"
                                    adFreeSecondsRemaining > 0 -> {
                                        val hours = adFreeSecondsRemaining / 3600
                                        val mins = (adFreeSecondsRemaining % 3600) / 60
                                        val secs = adFreeSecondsRemaining % 60
                                        String.format("%02d:%02d:%02d left (Adds +2h session)", hours, mins, secs)
                                    }
                                    else -> "Get Reward: dynamically adds +2 hours to active session"
                                },
                                fontSize = 11.sp,
                                color = Color(0xFF64748B)
                            )
                        }
                    }

                    if (!isPremium) {
                        Button(
                            onClick = onWatchRewardedAd,
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0F62FE)),
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier.testTag("watch_reward_btn")
                        ) {
                            Icon(imageVector = Icons.Default.PlayCircle, contentDescription = null, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Get Reward", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }

            // Navigation Bars Safety Spacer
            Spacer(modifier = Modifier.height(24.dp).navigationBarsPadding())
        }
    }
}
