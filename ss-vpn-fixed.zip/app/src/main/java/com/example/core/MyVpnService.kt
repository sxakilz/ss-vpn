package com.example.core

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.VpnService
import android.os.Build
import android.util.Log
import androidx.core.app.NotificationCompat
import com.example.MainActivity
import com.example.R
import com.example.vpn.TrafficStats
import com.example.vpn.VlessProfile
import com.example.vpn.VpnStatus
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeoutOrNull
import org.json.JSONObject
import java.net.InetSocketAddress
import java.net.Socket
import java.util.concurrent.atomic.AtomicLong

/**
 * Production Android VpnService backed by the native sing-box (libbox) VLESS Reality core.
 *
 * Enforces:
 * - Physical connectivity pre-check before touching TUN
 * - Strictly protected TUN (`172.19.0.1/30`, `0.0.0.0/0`, `AF_INET` on API 21+, app self-exclusion)
 * - Full sing-box VLESS Reality (`xtls-rprx-vision`, `xudp`) outbound with `"final": "proxy"` & `hijack-dns`
 * - 4-second VPS socket handshake verification & auto-fallback (never shows fake connected state)
 * - Real sing-box CommandClient telemetry for upload/download speeds and byte totals
 */
class MyVpnService : VpnService() {

    private var singBoxEngine: SingBoxEngine? = null
    private var workerJob: Job? = null
    private val serviceJob = SupervisorJob()
    private val scope = CoroutineScope(Dispatchers.IO + serviceJob)

    private val liveUpRateBytesPerSec = AtomicLong(0L)
    private val liveDownRateBytesPerSec = AtomicLong(0L)
    private val liveTotalUpBytes = AtomicLong(0L)
    private val liveTotalDownBytes = AtomicLong(0L)

    private var activeProfile: VlessProfile? = null
    private var startTimeMillis: Long = 0L

    override fun onCreate() {
        super.onCreate()
        currentInstance = this
        _activeOutboundTag.value = "proxy"
        ensureNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_CONNECT -> {
                val configJson = intent.getStringExtra(EXTRA_CONFIG_JSON)
                val profile = if (!configJson.isNullOrEmpty()) {
                    try {
                        val obj = JSONObject(configJson)
                        VlessProfile(
                            id = obj.optString("id"),
                            remarks = obj.optString("remarks", ConfigManager.DEFAULT_REMARKS),
                            address = obj.optString("address", ConfigManager.DEFAULT_SERVER_IP),
                            port = obj.optInt("port", ConfigManager.DEFAULT_PORT),
                            uuid = obj.optString("uuid", ConfigManager.DEFAULT_UUID),
                            flow = obj.optString("flow", ConfigManager.DEFAULT_FLOW),
                            security = obj.optString("security", ConfigManager.DEFAULT_SECURITY),
                            sni = obj.optString("sni", ConfigManager.DEFAULT_SNI),
                            fingerprint = obj.optString("fingerprint", ConfigManager.DEFAULT_FINGERPRINT),
                            packetEncoding = obj.optString("packetEncoding", ConfigManager.DEFAULT_PACKET_ENCODING),
                            publicKey = obj.optString("publicKey", ConfigManager.DEFAULT_PUBLIC_KEY),
                            shortId = obj.optString("shortId", ConfigManager.DEFAULT_SHORT_ID)
                        )
                    } catch (_: Exception) {
                        ConfigManager.DEFAULT_PROFILE
                    }
                } else {
                    ConfigManager.DEFAULT_PROFILE
                }

                startTunnel(profile)
            }
            ACTION_DISCONNECT -> {
                stopTunnel()
            }
        }
        return START_NOT_STICKY
    }

    override fun onRevoke() {
        stopTunnel()
        super.onRevoke()
    }

    private fun isPhysicalNetworkAvailable(): Boolean {
        val connectivityManager = getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager ?: return false
        val network = connectivityManager.activeNetwork ?: return false
        val capabilities = connectivityManager.getNetworkCapabilities(network) ?: return false
        return capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) &&
            (capabilities.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) ||
                capabilities.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) ||
                capabilities.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET))
    }

    private fun startTunnel(profile: VlessProfile) {
        // startForegroundService() requires startForeground() within ~5s on EVERY path,
        // including the early-return below, otherwise the app is killed.
        startForeground(NOTIFICATION_ID, createNotification("Connecting to SS VPN (Smart Secured)..."))

        // 1. Mandatory Physical Pre-Check
        if (!isPhysicalNetworkAvailable()) {
            _vpnStatus.value = VpnStatus.DISCONNECTED
            _lastErrorMessage.value = "No Internet Connection"
            stopSelf()
            return
        }

        // Tear down any previous core instance cleanly before starting a new session
        workerJob?.cancel()
        workerJob = null
        singBoxEngine?.stop()
        singBoxEngine = null

        activeProfile = profile
        appendLog("[app] Connecting to ${profile.address}:${profile.port} (sni=${profile.sni}, flow=${profile.flow})")
        _vpnStatus.value = VpnStatus.CONNECTING
        _lastErrorMessage.value = null

        workerJob = scope.launch {
            try {
                // Measure initial direct VPS latency via protected socket
                val initialPing = measurePing(profile.address, profile.port)
                if (initialPing > 0) {
                    _pingMs.value = initialPing
                }

                // 2. Generate verified anti-leak sing-box 1.12+ JSON configuration with loopback probe
                val configManager = ConfigManager(this@MyVpnService)
                val probePort = SingBoxEngine.findFreeLocalPort()
                val singboxConfigJson = configManager.buildSingboxConfigJson(
                    profile = profile,
                    socksProbePort = probePort
                )

                liveUpRateBytesPerSec.set(0L)
                liveDownRateBytesPerSec.set(0L)
                liveTotalUpBytes.set(0L)
                liveTotalDownBytes.set(0L)

                // 3. Start native sing-box (libbox) core -> validates config, opens TUN, dials VLESS Reality
                val engine = SingBoxEngine(this@MyVpnService)
                singBoxEngine = engine

                engine.start(
                    configJson = singboxConfigJson,
                    onTrafficStatus = { statusMsg ->
                        liveUpRateBytesPerSec.set(statusMsg.uplink)
                        liveDownRateBytesPerSec.set(statusMsg.downlink)
                        liveTotalUpBytes.set(statusMsg.uplinkTotal)
                        liveTotalDownBytes.set(statusMsg.downlinkTotal)
                    },
                    onLogMessage = { logLine ->
                        Log.d(TAG, "[sing-box] $logLine")
                        appendLog("[sing-box] $logLine")
                    },
                    onUnexpectedStop = { reason ->
                        if (_vpnStatus.value == VpnStatus.CONNECTED || _vpnStatus.value == VpnStatus.CONNECTING) {
                            if (!reason.isNullOrBlank()) {
                                _lastErrorMessage.value = "Tunnel disconnected: $reason"
                            }
                            stopTunnel()
                        }
                    }
                )

                // Confirm TUN was established by sing-box PlatformInterface
                if (engine.currentTunDescriptor == null) {
                    _lastErrorMessage.value = "Connection Failed: Unable to initialize VPN TUN interface"
                    stopTunnel()
                    return@launch
                }

                // 4A. Real 4-second VPS TCP Handshake Validation (Anti-Fake Connection Guard)
                val isHandshakeValid = withTimeoutOrNull(4000L) {
                    validateServerHandshake(profile)
                } ?: false

                appendLog("[app] VPS TCP handshake ok=$isHandshakeValid, tun fd ready=${engine.currentTunDescriptor != null}")
                if (!isHandshakeValid) {
                    _lastErrorMessage.value = "Connection Failed: VPS Unreachable / Fake Connection Prevented"
                    stopTunnel()
                    return@launch
                }

                // 4B. End-to-End VLESS Reality + DNS + HTTPS Egress Verification inside sing-box
                val tunnelProbe = withTimeoutOrNull(25_000L) {
                    SingBoxEngine.verifyEndToEndTunnel(
                        socksPort = probePort,
                        timeoutMs = 7000,
                        coreLogProvider = { engine.getRecentLogs() },
                        socketProtector = { sock -> protect(sock) }
                    )
                } ?: SingBoxEngine.TunnelProbeResult(
                    success = false,
                    failureStage = SingBoxEngine.TunnelFailureStage.HTTP_READ_TIMEOUT,
                    errorDetail = SingBoxEngine.diagnoseProbeFailure(
                        stage = SingBoxEngine.TunnelFailureStage.HTTP_READ_TIMEOUT,
                        targetHost = "connectivitycheck.gstatic.com / ifconfig.me",
                        coreLogs = engine.getRecentLogs(),
                        rawDetail = "HTTPS tunnel verification exceeded 25s total budget"
                    ).second
                )

                appendLog("[app] SOCKS e2e probe success=${tunnelProbe.success} stage=${tunnelProbe.failureStage} ip=${tunnelProbe.exitIp} detail=${tunnelProbe.errorDetail}")
                if (!tunnelProbe.success) {
                    val detail = tunnelProbe.errorDetail ?: "VLESS Reality HTTPS verification failed"
                    _lastErrorMessage.value =
                        if (tunnelProbe.failureStage == SingBoxEngine.TunnelFailureStage.ENVIRONMENT_SANDBOX_BLOCKED) {
                            "Preview Sandbox Restriction: $detail"
                        } else {
                            "Connection Failed: $detail"
                        }
                    stopTunnel()
                    return@launch
                }

                if (tunnelProbe.latencyMs > 0) {
                    _pingMs.value = tunnelProbe.latencyMs
                }
                _verifiedExitIp.value = tunnelProbe.exitIp

                // 5. Verified sing-box TUN + VLESS Reality end-to-end internet: enter CONNECTED state
                startTimeMillis = System.currentTimeMillis()
                _vpnStatus.value = VpnStatus.CONNECTED
                _connectedProfile.value = profile
                _activeOutboundTag.value = "proxy"

                val pingLabel = if (_pingMs.value > 0) "${_pingMs.value} ms" else "Protected"
                updateNotification("Protected • SS VPN (Smart Secured) • $pingLabel")

                var tick = 0L
                while (isActive && singBoxEngine != null && engine.currentTunDescriptor != null) {
                    delay(1000L)
                    tick++

                    val duration = (System.currentTimeMillis() - startTimeMillis) / 1000L + sessionBonusSeconds

                    if (tick % 15L == 0L) {
                        val newPing = measurePing(profile.address, profile.port)
                        if (newPing > 0) {
                            _pingMs.value = newPing
                            updateNotification("Protected • SS VPN (Smart Secured) • $newPing ms")
                        }
                    }

                    _stats.value = SingBoxEngine.calculateLiveTrafficStats(
                        uplinkBytesPerSec = liveUpRateBytesPerSec.get(),
                        downlinkBytesPerSec = liveDownRateBytesPerSec.get(),
                        totalUploadBytes = liveTotalUpBytes.get(),
                        totalDownloadBytes = liveTotalDownBytes.get(),
                        durationSeconds = duration
                    )
                }
                if (isActive && engine.currentTunDescriptor == null && _vpnStatus.value == VpnStatus.CONNECTED) {
                    _lastErrorMessage.value = "Connection Failed: VPN TUN interface closed unexpectedly"
                    stopTunnel()
                }
            } catch (e: Exception) {
                Log.e(TAG, "sing-box tunnel startup failed: ${e.message}", e)
                _lastErrorMessage.value = if (e.message?.contains("config", ignoreCase = true) == true) {
                    "Connection Failed: Core Config Error (${e.message})"
                } else {
                    "Connection Failed: VPS Unreachable / Fake Connection Prevented"
                }
                stopTunnel()
            }
        }
    }

    private fun validateServerHandshake(profile: VlessProfile): Boolean {
        return try {
            val socket = Socket()
            if (!protect(socket)) {
                Log.w(TAG, "protect(handshakeSocket) returned false for ${profile.address}:${profile.port}")
            }
            val start = System.currentTimeMillis()
            socket.connect(InetSocketAddress(profile.address, profile.port), 4000)
            val latency = (System.currentTimeMillis() - start).toInt()
            if (latency > 0) _pingMs.value = latency
            socket.close()
            true
        } catch (_: Exception) {
            try {
                val fallbackSocket = Socket()
                if (!protect(fallbackSocket)) {
                    Log.w(TAG, "protect(fallbackHandshakeSocket) returned false for ${profile.address}:${profile.port}")
                }
                fallbackSocket.connect(InetSocketAddress(profile.address, profile.port), 4000)
                fallbackSocket.close()
                true
            } catch (_: Exception) {
                false
            }
        }
    }

    private fun stopTunnel() {
        _vpnStatus.value = VpnStatus.DISCONNECTING

        workerJob?.cancel()
        workerJob = null

        try {
            singBoxEngine?.stop()
        } catch (e: Exception) {
            Log.w(TAG, "Error stopping SingBoxEngine: ${e.message}")
        }
        singBoxEngine = null

        _vpnStatus.value = VpnStatus.DISCONNECTED
        _connectedProfile.value = null
        _verifiedExitIp.value = null
        _stats.value = TrafficStats()
        _pingMs.value = 0

        try {
            stopForeground(STOP_FOREGROUND_REMOVE)
        } catch (_: Exception) {}
        stopSelf()
    }

    override fun onDestroy() {
        stopTunnel()
        serviceJob.cancel()
        if (currentInstance === this) {
            currentInstance = null
        }
        super.onDestroy()
    }

    private fun measurePing(host: String, port: Int): Int {
        return try {
            val start = System.currentTimeMillis()
            val socket = Socket()
            if (!protect(socket)) {
                Log.w(TAG, "protect(pingSocket) returned false for $host:$port")
            }
            socket.connect(InetSocketAddress(host, port), 2000)
            val latency = (System.currentTimeMillis() - start).toInt()
            socket.close()
            latency
        } catch (_: Exception) {
            -1
        }
    }

    private fun ensureNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "SS VPN Tunnel Service",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Shows live connection status for SS VPN"
                setShowBadge(false)
            }
            val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            manager.createNotificationChannel(channel)
        }
    }

    private fun createNotification(text: String): Notification {
        val openIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val pendingOpen = PendingIntent.getActivity(
            this,
            0,
            openIntent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val disconnectIntent = Intent(this, MyVpnService::class.java).apply {
            action = ACTION_DISCONNECT
        }
        val pendingDisconnect = PendingIntent.getService(
            this,
            1,
            disconnectIntent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("SS VPN")
            .setContentText(text)
            .setSmallIcon(R.drawable.vpn_launcher_icon_1792312872182)
            .setContentIntent(pendingOpen)
            .setOngoing(true)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Disconnect", pendingDisconnect)
            .build()
    }

    private fun updateNotification(text: String) {
        try {
            val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            manager.notify(NOTIFICATION_ID, createNotification(text))
        } catch (_: Exception) {}
    }

    companion object {
        private const val TAG = "MyVpnService"
        const val ACTION_CONNECT = "com.ss.vpn.ACTION_CONNECT"
        const val ACTION_DISCONNECT = "com.ss.vpn.ACTION_DISCONNECT"
        const val EXTRA_CONFIG_JSON = "extra_config_json"

        const val CHANNEL_ID = "ss_vpn_status_channel"
        const val NOTIFICATION_ID = 2001

        private val _vpnStatus = MutableStateFlow(VpnStatus.DISCONNECTED)
        val vpnStatus = _vpnStatus.asStateFlow()

        private val _activeOutboundTag = MutableStateFlow("proxy")
        val activeOutboundTag = _activeOutboundTag.asStateFlow()

        private val _lastErrorMessage = MutableStateFlow<String?>(null)
        val lastErrorMessage = _lastErrorMessage.asStateFlow()

        private val _connectedProfile = MutableStateFlow<VlessProfile?>(null)
        val connectedProfile = _connectedProfile.asStateFlow()

        private val _stats = MutableStateFlow(TrafficStats())
        val stats = _stats.asStateFlow()

        private val _pingMs = MutableStateFlow(0)
        val pingMs = _pingMs.asStateFlow()

        private val _verifiedExitIp = MutableStateFlow<String?>(null)
        val verifiedExitIp = _verifiedExitIp.asStateFlow()

        private var sessionBonusSeconds: Long = 0L

        private val _logs = MutableStateFlow<List<String>>(emptyList())
        val logs = _logs.asStateFlow()

        @Synchronized
        fun appendLog(line: String) {
            val next = _logs.value + line
            _logs.value = if (next.size > 400) next.takeLast(400) else next
        }

        @Synchronized
        fun clearLogs() {
            _logs.value = emptyList()
        }

        @Volatile
        var currentInstance: MyVpnService? = null
            private set

        fun setOutboundTag(tag: String) {
            _activeOutboundTag.value = tag
        }

        fun addSessionBonus(seconds: Long) {
            sessionBonusSeconds += seconds
        }

        fun clearErrorMessage() {
            _lastErrorMessage.value = null
        }
    }
}
