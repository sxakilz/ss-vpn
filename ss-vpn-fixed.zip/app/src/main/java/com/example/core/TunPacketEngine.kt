package com.example.core

import android.net.VpnService
import android.os.ParcelFileDescriptor
import android.util.Log
import com.example.vpn.VlessProfile
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.IOException
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.Socket
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.random.Random

/**
 * High-performance, pure-Kotlin TUN Packet Processing Engine for Android VpnService.
 *
 * Resolves the "No website is loaded" black-hole issue by actively reading IPv4 Layer 3 packets
 * from the TUN descriptor (vpnInterface), resolving DNS queries (UDP:53) over protected sockets
 * without "DNS_PROBE_STARTED" failures, responding to ICMP ping echo requests, and relaying
 * TCP connections (HTTP/HTTPS) through protected outbound sockets with zero routing loops.
 */
class TunPacketEngine(
    private val vpnService: VpnService,
    private val pfd: ParcelFileDescriptor,
    private val profile: VlessProfile,
    private val onTrafficUpdate: (upBytes: Long, downBytes: Long) -> Unit
) {

    private val isRunning = AtomicBoolean(false)
    private var readerThread: Thread? = null
    private val scope = CoroutineScope(Dispatchers.IO + Job())

    private val inputStream = FileInputStream(pfd.fileDescriptor)
    private val outputStream = FileOutputStream(pfd.fileDescriptor)
    private val writeLock = Any()

    private val tcpSessions = ConcurrentHashMap<String, TcpSession>()

    // Primary and secondary DNS resolvers
    private val dnsServers = listOf(
        InetAddress.getByName("8.8.8.8"),
        InetAddress.getByName("1.1.1.1")
    )

    fun start() {
        if (!isRunning.compareAndSet(false, true)) return

        readerThread = Thread({
            val buffer = ByteArray(32768)
            while (isRunning.get()) {
                try {
                    val length = inputStream.read(buffer)
                    if (length <= 0) break

                    processIncomingTunPacket(buffer, length)
                } catch (e: IOException) {
                    // PFD closed on VPN disconnect
                    break
                } catch (e: Exception) {
                    if (!isRunning.get()) break
                    Log.e(TAG, "Error processing TUN packet: ${e.message}")
                }
            }
            cleanup()
        }, "SS-Vpn-Tun-Reader").apply {
            isDaemon = true
            start()
        }
    }

    fun stop() {
        if (!isRunning.compareAndSet(true, false)) return
        cleanup()
    }

    private fun cleanup() {
        tcpSessions.values.forEach { it.close() }
        tcpSessions.clear()
        try {
            readerThread?.interrupt()
        } catch (_: Exception) {}
        readerThread = null
    }

    private fun processIncomingTunPacket(buffer: ByteArray, length: Int) {
        if (length < 20) return

        val version = (buffer[0].toInt() and 0xF0) ushr 4
        if (version != 4) return // Enforce strict IPv4 handling

        val ihl = (buffer[0].toInt() and 0x0F) * 4
        if (ihl < 20 || length < ihl) return

        val totalLength = ((buffer[2].toInt() and 0xFF) shl 8) or (buffer[3].toInt() and 0xFF)
        val packetLength = minOf(length, totalLength)

        val protocol = buffer[9].toInt() and 0xFF

        val srcIp = ByteArray(4).apply { System.arraycopy(buffer, 12, this, 0, 4) }
        val dstIp = ByteArray(4).apply { System.arraycopy(buffer, 16, this, 0, 4) }

        onTrafficUpdate(packetLength.toLong(), 0L)

        when (protocol) {
            17 -> handleUdpPacket(buffer, ihl, packetLength, srcIp, dstIp)
            6 -> handleTcpPacket(buffer, ihl, packetLength, srcIp, dstIp)
            1 -> handleIcmpPacket(buffer, ihl, packetLength, srcIp, dstIp)
        }
    }

    // =========================================================================
    // 1. DNS & UDP Forwarding (Direct Resolution without DNS_PROBE_STARTED)
    // =========================================================================

    private fun handleUdpPacket(
        buffer: ByteArray,
        ihl: Int,
        totalLength: Int,
        srcIp: ByteArray,
        dstIp: ByteArray
    ) {
        if (totalLength < ihl + 8) return

        val srcPort = ((buffer[ihl].toInt() and 0xFF) shl 8) or (buffer[ihl + 1].toInt() and 0xFF)
        val dstPort = ((buffer[ihl + 2].toInt() and 0xFF) shl 8) or (buffer[ihl + 3].toInt() and 0xFF)
        val udpLen = ((buffer[ihl + 4].toInt() and 0xFF) shl 8) or (buffer[ihl + 5].toInt() and 0xFF)

        val payloadOffset = ihl + 8
        val payloadLen = minOf(udpLen - 8, totalLength - payloadOffset)
        if (payloadLen <= 0) return

        // Intercept DNS queries (port 53)
        if (dstPort == 53) {
            val queryData = ByteArray(payloadLen)
            System.arraycopy(buffer, payloadOffset, queryData, 0, payloadLen)

            scope.launch {
                forwardDnsQuery(queryData, srcIp, srcPort, dstIp)
            }
        }
    }

    private fun forwardDnsQuery(
        queryData: ByteArray,
        clientIp: ByteArray,
        clientPort: Int,
        originalDnsServerIp: ByteArray
    ) {
        var resolved = false
        for (dnsServer in dnsServers) {
            if (resolved) break
            var socket: DatagramSocket? = null
            try {
                socket = DatagramSocket()
                // Protect socket to bypass VPN TUN interface and route over physical network
                vpnService.protect(socket)
                socket.soTimeout = 2500

                val sendPacket = DatagramPacket(queryData, queryData.size, dnsServer, 53)
                socket.send(sendPacket)

                val recvBuf = ByteArray(4096)
                val recvPacket = DatagramPacket(recvBuf, recvBuf.size)
                socket.receive(recvPacket)

                val responsePayload = ByteArray(recvPacket.length).apply {
                    System.arraycopy(recvPacket.data, 0, this, 0, recvPacket.length)
                }

                // Construct and send IPv4 UDP response back to TUN
                sendUdpResponseToTun(
                    srcIp = originalDnsServerIp,
                    srcPort = 53,
                    dstIp = clientIp,
                    dstPort = clientPort,
                    payload = responsePayload
                )
                onTrafficUpdate(0L, responsePayload.size.toLong())
                resolved = true
            } catch (_: Exception) {
                // Try next DNS server on timeout/failure
            } finally {
                socket?.close()
            }
        }
    }

    private fun sendUdpResponseToTun(
        srcIp: ByteArray,
        srcPort: Int,
        dstIp: ByteArray,
        dstPort: Int,
        payload: ByteArray
    ) {
        val totalLength = 20 + 8 + payload.size
        val packet = ByteArray(totalLength)

        // IPv4 Header
        packet[0] = 0x45.toByte() // Version 4, IHL 5 (20 bytes)
        packet[1] = 0x00.toByte() // DSCP / ECN
        writeShort(packet, 2, totalLength)
        writeShort(packet, 4, Random.nextInt(1, 65535)) // Identification
        writeShort(packet, 6, 0x4000) // Flags: Don't Fragment
        packet[8] = 64.toByte() // TTL
        packet[9] = 17.toByte() // Protocol UDP
        writeShort(packet, 10, 0) // Checksum placeholder
        System.arraycopy(srcIp, 0, packet, 12, 4)
        System.arraycopy(dstIp, 0, packet, 16, 4)

        val ipChecksum = computeChecksum(packet, 0, 20)
        writeShort(packet, 10, ipChecksum)

        // UDP Header
        val udpOffset = 20
        writeShort(packet, udpOffset, srcPort)
        writeShort(packet, udpOffset + 2, dstPort)
        writeShort(packet, udpOffset + 4, 8 + payload.size)
        writeShort(packet, udpOffset + 6, 0) // UDP checksum is optional in IPv4 (0 = none)

        // UDP Payload
        System.arraycopy(payload, 0, packet, udpOffset + 8, payload.size)

        writePacket(packet, totalLength)
    }

    // =========================================================================
    // 2. ICMP Echo (Ping) Responder
    // =========================================================================

    private fun handleIcmpPacket(
        buffer: ByteArray,
        ihl: Int,
        totalLength: Int,
        srcIp: ByteArray,
        dstIp: ByteArray
    ) {
        if (totalLength < ihl + 8) return

        val type = buffer[ihl].toInt() and 0xFF
        val code = buffer[ihl + 1].toInt() and 0xFF

        // Echo Request (Ping)
        if (type == 8 && code == 0) {
            val reply = ByteArray(totalLength)
            System.arraycopy(buffer, 0, reply, 0, totalLength)

            // Swap IPs
            System.arraycopy(dstIp, 0, reply, 12, 4)
            System.arraycopy(srcIp, 0, reply, 16, 4)

            // Recalculate IP Checksum
            writeShort(reply, 10, 0)
            val ipChecksum = computeChecksum(reply, 0, ihl)
            writeShort(reply, 10, ipChecksum)

            // Change ICMP Type to 0 (Echo Reply)
            reply[ihl] = 0.toByte()
            writeShort(reply, ihl + 2, 0)
            val icmpChecksum = computeChecksum(reply, ihl, totalLength - ihl)
            writeShort(reply, ihl + 2, icmpChecksum)

            writePacket(reply, totalLength)
        }
    }

    // =========================================================================
    // 3. TCP Connection Relay (Tun2Socket Web Routing)
    // =========================================================================

    private fun handleTcpPacket(
        buffer: ByteArray,
        ihl: Int,
        totalLength: Int,
        srcIp: ByteArray,
        dstIp: ByteArray
    ) {
        if (totalLength < ihl + 20) return

        val srcPort = ((buffer[ihl].toInt() and 0xFF) shl 8) or (buffer[ihl + 1].toInt() and 0xFF)
        val dstPort = ((buffer[ihl + 2].toInt() and 0xFF) shl 8) or (buffer[ihl + 3].toInt() and 0xFF)

        val seq = readInt(buffer, ihl + 4)
        val ack = readInt(buffer, ihl + 8)

        val dataOffset = ((buffer[ihl + 12].toInt() and 0xF0) ushr 4) * 4
        val flags = buffer[ihl + 13].toInt() and 0xFF

        val isSyn = (flags and 0x02) != 0
        val isAck = (flags and 0x10) != 0
        val isFin = (flags and 0x01) != 0
        val isRst = (flags and 0x04) != 0

        val payloadOffset = ihl + dataOffset
        val payloadLen = maxOf(0, totalLength - payloadOffset)

        val sessionKey = "${formatIp(srcIp)}:$srcPort->${formatIp(dstIp)}:$dstPort"

        if (isSyn && !isAck) {
            // New TCP Connection handshake
            val session = TcpSession(
                srcIp = srcIp,
                srcPort = srcPort,
                dstIp = dstIp,
                dstPort = dstPort,
                initialClientSeq = seq
            )
            tcpSessions[sessionKey] = session
            session.connectAndStart(buffer, ihl)
        } else {
            val session = tcpSessions[sessionKey]
            if (session != null) {
                if (isRst) {
                    session.close()
                    tcpSessions.remove(sessionKey)
                } else if (isFin) {
                    session.handleFin(seq)
                    session.close()
                    tcpSessions.remove(sessionKey)
                } else if (payloadLen > 0) {
                    val data = ByteArray(payloadLen)
                    System.arraycopy(buffer, payloadOffset, data, 0, payloadLen)
                    session.sendData(data, seq)
                }
            } else if (!isRst) {
                // Unknown session -> send RST to reset connection gracefully
                sendTcpPacket(
                    srcIp = dstIp,
                    srcPort = dstPort,
                    dstIp = srcIp,
                    dstPort = srcPort,
                    seq = ack,
                    ack = (seq + 1) and 0xFFFFFFFFL,
                    flags = 0x14, // RST | ACK
                    payload = null
                )
            }
        }
    }

    private fun writePacket(packet: ByteArray, length: Int) {
        synchronized(writeLock) {
            try {
                outputStream.write(packet, 0, length)
                outputStream.flush()
            } catch (_: Exception) {}
        }
    }

    private fun sendTcpPacket(
        srcIp: ByteArray,
        srcPort: Int,
        dstIp: ByteArray,
        dstPort: Int,
        seq: Long,
        ack: Long,
        flags: Int,
        payload: ByteArray?,
        includeMssOption: Boolean = false
    ) {
        val payloadSize = payload?.size ?: 0
        val tcpHeaderLen = if (includeMssOption) 24 else 20
        val totalLength = 20 + tcpHeaderLen + payloadSize

        val packet = ByteArray(totalLength)

        // IPv4 Header
        packet[0] = 0x45.toByte()
        packet[1] = 0x00.toByte()
        writeShort(packet, 2, totalLength)
        writeShort(packet, 4, Random.nextInt(1, 65535))
        writeShort(packet, 6, 0x4000) // Don't fragment
        packet[8] = 64.toByte()
        packet[9] = 6.toByte() // TCP
        writeShort(packet, 10, 0)
        System.arraycopy(srcIp, 0, packet, 12, 4)
        System.arraycopy(dstIp, 0, packet, 16, 4)

        val ipChecksum = computeChecksum(packet, 0, 20)
        writeShort(packet, 10, ipChecksum)

        // TCP Header
        val tcpOffset = 20
        writeShort(packet, tcpOffset, srcPort)
        writeShort(packet, tcpOffset + 2, dstPort)
        writeInt(packet, tcpOffset + 4, seq)
        writeInt(packet, tcpOffset + 8, ack)

        val dataOffsetWords = tcpHeaderLen / 4
        packet[tcpOffset + 12] = ((dataOffsetWords shl 4) and 0xF0).toByte()
        packet[tcpOffset + 13] = flags.toByte()
        writeShort(packet, tcpOffset + 14, 65535) // Window size
        writeShort(packet, tcpOffset + 16, 0) // Checksum placeholder
        writeShort(packet, tcpOffset + 18, 0) // Urgent pointer

        if (includeMssOption) {
            // Option: Maximum Segment Size (MSS) = 1460 (0x05B4)
            packet[tcpOffset + 20] = 0x02.toByte() // Option Kind: MSS
            packet[tcpOffset + 21] = 0x04.toByte() // Option Length: 4
            packet[tcpOffset + 22] = 0x05.toByte()
            packet[tcpOffset + 23] = 0xB4.toByte()
        }

        if (payload != null && payloadSize > 0) {
            System.arraycopy(payload, 0, packet, tcpOffset + tcpHeaderLen, payloadSize)
        }

        val tcpChecksum = computeTcpChecksum(srcIp, dstIp, packet, tcpOffset, tcpHeaderLen + payloadSize)
        writeShort(packet, tcpOffset + 16, tcpChecksum)

        writePacket(packet, totalLength)
    }

    // =========================================================================
    // TCP Session Manager (Connects Outbound Socket via Physical Network)
    // =========================================================================

    private inner class TcpSession(
        val srcIp: ByteArray,
        val srcPort: Int,
        val dstIp: ByteArray,
        val dstPort: Int,
        initialClientSeq: Long
    ) {
        var clientSeq: Long = (initialClientSeq + 1) and 0xFFFFFFFFL
        var mySeq: Long = Random.nextLong(100000, 900000)

        private var outboundSocket: Socket? = null
        private var job: Job? = null
        private val isClosed = AtomicBoolean(false)

        fun connectAndStart(synBuffer: ByteArray, synIhl: Int) {
            job = scope.launch {
                try {
                    val socket = Socket()
                    // CRITICAL: Protect socket so connection routes over physical Wi-Fi/Cellular, NOT through TUN
                    vpnService.protect(socket)
                    socket.tcpNoDelay = true
                    socket.soTimeout = 15000

                    val targetAddress = InetAddress.getByAddress(dstIp)
                    socket.connect(InetSocketAddress(targetAddress, dstPort), 4000)
                    outboundSocket = socket

                    // 1. Handshake: Send TCP SYN-ACK back to TUN client
                    sendTcpPacket(
                        srcIp = dstIp,
                        srcPort = dstPort,
                        dstIp = srcIp,
                        dstPort = srcPort,
                        seq = mySeq,
                        ack = clientSeq,
                        flags = 0x12, // SYN | ACK
                        payload = null,
                        includeMssOption = true
                    )
                    mySeq = (mySeq + 1) and 0xFFFFFFFFL

                    // 2. Read from outbound web server and stream back to TUN
                    val inStream = socket.getInputStream()
                    val recvBuf = ByteArray(16384)

                    while (isRunning.get() && !isClosed.get()) {
                        val bytesRead = inStream.read(recvBuf)
                        if (bytesRead <= 0) break

                        val chunk = ByteArray(bytesRead)
                        System.arraycopy(recvBuf, 0, chunk, 0, bytesRead)

                        sendTcpPacket(
                            srcIp = dstIp,
                            srcPort = dstPort,
                            dstIp = srcIp,
                            dstPort = srcPort,
                            seq = mySeq,
                            ack = clientSeq,
                            flags = 0x18, // PSH | ACK
                            payload = chunk
                        )

                        mySeq = (mySeq + bytesRead) and 0xFFFFFFFFL
                        onTrafficUpdate(0L, bytesRead.toLong())
                    }

                    // Server closed connection -> send FIN-ACK to client
                    if (!isClosed.get()) {
                        sendTcpPacket(
                            srcIp = dstIp,
                            srcPort = dstPort,
                            dstIp = srcIp,
                            dstPort = srcPort,
                            seq = mySeq,
                            ack = clientSeq,
                            flags = 0x11, // FIN | ACK
                            payload = null
                        )
                    }
                } catch (e: Exception) {
                    // On connection failure send RST to client
                    if (!isClosed.get()) {
                        sendTcpPacket(
                            srcIp = dstIp,
                            srcPort = dstPort,
                            dstIp = srcIp,
                            dstPort = srcPort,
                            seq = mySeq,
                            ack = clientSeq,
                            flags = 0x14, // RST | ACK
                            payload = null
                        )
                    }
                } finally {
                    close()
                }
            }
        }

        fun sendData(data: ByteArray, seq: Long) {
            scope.launch {
                try {
                    val socket = outboundSocket
                    if (socket != null && !socket.isClosed) {
                        socket.getOutputStream().write(data)
                        socket.getOutputStream().flush()
                        onTrafficUpdate(data.size.toLong(), 0L)

                        // Acknowledge receipt of data to TUN client
                        clientSeq = (seq + data.size) and 0xFFFFFFFFL
                        sendTcpPacket(
                            srcIp = dstIp,
                            srcPort = dstPort,
                            dstIp = srcIp,
                            dstPort = srcPort,
                            seq = mySeq,
                            ack = clientSeq,
                            flags = 0x10, // ACK
                            payload = null
                        )
                    }
                } catch (_: Exception) {
                    close()
                }
            }
        }

        fun handleFin(seq: Long) {
            clientSeq = (seq + 1) and 0xFFFFFFFFL
            sendTcpPacket(
                srcIp = dstIp,
                srcPort = dstPort,
                dstIp = srcIp,
                dstPort = srcPort,
                seq = mySeq,
                ack = clientSeq,
                flags = 0x10, // ACK
                payload = null
            )
        }

        fun close() {
            if (isClosed.compareAndSet(false, true)) {
                job?.cancel()
                try {
                    outboundSocket?.close()
                } catch (_: Exception) {}
                outboundSocket = null
            }
        }
    }

    // =========================================================================
    // Utilities & Checksums
    // =========================================================================

    companion object {
        private const val TAG = "TunPacketEngine"

        fun formatIp(bytes: ByteArray): String {
            return "${bytes[0].toInt() and 0xFF}.${bytes[1].toInt() and 0xFF}.${bytes[2].toInt() and 0xFF}.${bytes[3].toInt() and 0xFF}"
        }

        fun readInt(buffer: ByteArray, offset: Int): Long {
            return (((buffer[offset].toLong() and 0xFF) shl 24) or
                    ((buffer[offset + 1].toLong() and 0xFF) shl 16) or
                    ((buffer[offset + 2].toLong() and 0xFF) shl 8) or
                    (buffer[offset + 3].toLong() and 0xFF)) and 0xFFFFFFFFL
        }

        fun writeInt(buffer: ByteArray, offset: Int, value: Long) {
            buffer[offset] = ((value ushr 24) and 0xFF).toByte()
            buffer[offset + 1] = ((value ushr 16) and 0xFF).toByte()
            buffer[offset + 2] = ((value ushr 8) and 0xFF).toByte()
            buffer[offset + 3] = (value and 0xFF).toByte()
        }

        fun writeShort(buffer: ByteArray, offset: Int, value: Int) {
            buffer[offset] = ((value ushr 8) and 0xFF).toByte()
            buffer[offset + 1] = (value and 0xFF).toByte()
        }

        fun computeChecksum(buffer: ByteArray, offset: Int, length: Int): Int {
            var sum = 0
            var i = offset
            val end = offset + length
            while (i < end - 1) {
                val word = ((buffer[i].toInt() and 0xFF) shl 8) or (buffer[i + 1].toInt() and 0xFF)
                sum += word
                i += 2
            }
            if (i < end) {
                val word = (buffer[i].toInt() and 0xFF) shl 8
                sum += word
            }
            while ((sum ushr 16) > 0) {
                sum = (sum and 0xFFFF) + (sum ushr 16)
            }
            return sum.inv() and 0xFFFF
        }

        fun computeTcpChecksum(
            srcIp: ByteArray,
            dstIp: ByteArray,
            packet: ByteArray,
            tcpOffset: Int,
            tcpLength: Int
        ): Int {
            var sum = 0

            // IPv4 Pseudo Header
            sum += ((srcIp[0].toInt() and 0xFF) shl 8) or (srcIp[1].toInt() and 0xFF)
            sum += ((srcIp[2].toInt() and 0xFF) shl 8) or (srcIp[3].toInt() and 0xFF)
            sum += ((dstIp[0].toInt() and 0xFF) shl 8) or (dstIp[1].toInt() and 0xFF)
            sum += ((dstIp[2].toInt() and 0xFF) shl 8) or (dstIp[3].toInt() and 0xFF)
            sum += 6 // Protocol TCP
            sum += tcpLength

            // TCP Header & Payload (checksum field must be 0)
            var i = tcpOffset
            val end = tcpOffset + tcpLength
            while (i < end - 1) {
                val word = ((packet[i].toInt() and 0xFF) shl 8) or (packet[i + 1].toInt() and 0xFF)
                sum += word
                i += 2
            }
            if (i < end) {
                val word = (packet[i].toInt() and 0xFF) shl 8
                sum += word
            }

            while ((sum ushr 16) > 0) {
                sum = (sum and 0xFFFF) + (sum ushr 16)
            }
            val res = sum.inv() and 0xFFFF
            return if (res == 0) 0xFFFF else res
        }
    }
}
