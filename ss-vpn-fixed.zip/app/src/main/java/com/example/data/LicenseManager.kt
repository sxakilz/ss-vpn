package com.example.data

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONArray
import java.util.UUID

sealed class KeyValidationResult {
    data class AdminUnlocked(val message: String) : KeyValidationResult()
    data class PremiumActivated(val days: Int, val message: String) : KeyValidationResult()
    data class Invalid(val error: String) : KeyValidationResult()
}

data class LicenseKeyRecord(
    val key: String,
    val days: Int,
    val createdAt: Long = System.currentTimeMillis(),
    val isRedeemed: Boolean = false,
    val note: String = ""
)

class LicenseManager(private val context: Context) {

    private val prefs = context.getSharedPreferences("reality_vpn_license", Context.MODE_PRIVATE)

    // Admin Passwords
    val adminKeys = listOf(
        "SSV-DKUQ-P2RA-GBNB"
    )

    private val _isPremium = MutableStateFlow(false)
    val isPremium: StateFlow<Boolean> = _isPremium.asStateFlow()

    private val _premiumExpiresAt = MutableStateFlow(0L)
    val premiumExpiresAt: StateFlow<Long> = _premiumExpiresAt.asStateFlow()

    private val _activeKey = MutableStateFlow("")
    val activeKey: StateFlow<String> = _activeKey.asStateFlow()

    private val _adFreeUntil = MutableStateFlow(0L)
    val adFreeUntil: StateFlow<Long> = _adFreeUntil.asStateFlow()

    private val _isAdminMode = MutableStateFlow(false)
    val isAdminMode: StateFlow<Boolean> = _isAdminMode.asStateFlow()

    private val _generatedKeys = MutableStateFlow<List<LicenseKeyRecord>>(emptyList())
    val generatedKeys: StateFlow<List<LicenseKeyRecord>> = _generatedKeys.asStateFlow()

    init {
        loadState()
    }

    private fun loadState() {
        val premium = prefs.getBoolean("is_premium", false)
        val expiry = prefs.getLong("premium_expires_at", 0L)
        val now = System.currentTimeMillis()

        if (premium && expiry > now) {
            _isPremium.value = true
            _premiumExpiresAt.value = expiry
            _activeKey.value = prefs.getString("active_key", "") ?: ""
        } else {
            _isPremium.value = false
            _premiumExpiresAt.value = 0L
        }

        val adFree = prefs.getLong("ad_free_until", 0L)
        _adFreeUntil.value = if (adFree > now) adFree else 0L

        loadGeneratedKeys()
    }

    private fun loadGeneratedKeys() {
        val json = prefs.getString("generated_keys_json", null)
        val list = mutableListOf<LicenseKeyRecord>()
        if (!json.isNullOrEmpty()) {
            try {
                val array = JSONArray(json)
                for (i in 0 until array.length()) {
                    val obj = array.getJSONObject(i)
                    list.add(
                        LicenseKeyRecord(
                            key = obj.getString("key"),
                            days = obj.getInt("days"),
                            createdAt = obj.getLong("createdAt"),
                            isRedeemed = obj.getBoolean("isRedeemed"),
                            note = obj.optString("note", "")
                        )
                    )
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        } else {
            // Seed sample 1-month keys for convenient testing
            list.add(LicenseKeyRecord(key = "PREM-30D-REALITY-101", days = 30, note = "Starter Month Key"))
            list.add(LicenseKeyRecord(key = "PREM-30D-VIP-8899", days = 30, note = "VIP Fast Track"))
            list.add(LicenseKeyRecord(key = "PREM-30D-FAST-5544", days = 30, note = "Promo Key"))
            saveGeneratedKeys(list)
        }
        _generatedKeys.value = list
    }

    private fun saveGeneratedKeys(list: List<LicenseKeyRecord>) {
        val array = JSONArray()
        list.forEach { r ->
            val obj = org.json.JSONObject()
            obj.put("key", r.key)
            obj.put("days", r.days)
            obj.put("createdAt", r.createdAt)
            obj.put("isRedeemed", r.isRedeemed)
            obj.put("note", r.note)
            array.put(obj)
        }
        prefs.edit().putString("generated_keys_json", array.toString()).apply()
        _generatedKeys.value = list
    }

    /**
     * Check if user is either Premium or has active Ad-Free reward.
     */
    fun isAdFreeActive(): Boolean {
        if (_isPremium.value && _premiumExpiresAt.value > System.currentTimeMillis()) {
            return true
        }
        return _adFreeUntil.value > System.currentTimeMillis()
    }

    /**
     * Remaining seconds of 2-Hour Ad-Free reward.
     */
    fun getRemainingAdFreeSeconds(): Long {
        val diff = _adFreeUntil.value - System.currentTimeMillis()
        return (diff / 1000L).coerceAtLeast(0L)
    }

    /**
     * Remaining days of 1-Month Premium.
     */
    fun getRemainingPremiumDays(): Int {
        val diff = _premiumExpiresAt.value - System.currentTimeMillis()
        if (diff <= 0) return 0
        return ((diff / (1000L * 60 * 60 * 24)) + 1).toInt()
    }

    /**
     * Validates an entered Key from the Menu Key Box.
     */
    fun validateAndProcessKey(inputKey: String): KeyValidationResult {
        val cleanKey = inputKey.trim()
        if (cleanKey.isEmpty()) {
            return KeyValidationResult.Invalid("Please enter a license key or secret password")
        }

        // 1. Check if Secret Admin Key / Password
        if (adminKeys.any { it.equals(cleanKey, ignoreCase = true) }) {
            _isAdminMode.value = true
            return KeyValidationResult.AdminUnlocked("Welcome Admin! Secret Management Console unlocked.")
        }

        // 2. Check if valid 1-Month Premium Key
        // Accept generated keys, matching keys in records, or pattern REALITY-30D / PREM-30D
        val foundKey = _generatedKeys.value.find { it.key.equals(cleanKey, ignoreCase = true) }
        val isRecognizedPattern = cleanKey.startsWith("PREM-30D-", ignoreCase = true) ||
                cleanKey.startsWith("REALITY-30D-", ignoreCase = true) ||
                cleanKey.equals("VIP-MONTH-KEY", ignoreCase = true) ||
                cleanKey.equals("PREMIUM-1MONTH", ignoreCase = true)

        if (foundKey != null || isRecognizedPattern) {
            val days = foundKey?.days ?: 30
            val expiry = System.currentTimeMillis() + (days.toLong() * 24 * 3600 * 1000L)
            _isPremium.value = true
            _premiumExpiresAt.value = expiry
            _activeKey.value = cleanKey

            prefs.edit()
                .putBoolean("is_premium", true)
                .putLong("premium_expires_at", expiry)
                .putString("active_key", cleanKey)
                .apply()

            if (foundKey != null) {
                val updated = _generatedKeys.value.map {
                    if (it.key.equals(cleanKey, ignoreCase = true)) it.copy(isRedeemed = true) else it
                }
                saveGeneratedKeys(updated)
            }

            return KeyValidationResult.PremiumActivated(
                days = days,
                message = "License key verified! 1-Month Premium Access activated."
            )
        }

        return KeyValidationResult.Invalid("Invalid license key or password. Please check your credentials.")
    }

    fun grantTwoHoursAdFree() {
        val durationMs = 2L * 60 * 60 * 1000L // 2 hours
        val newExpiry = System.currentTimeMillis() + durationMs
        _adFreeUntil.value = newExpiry
        prefs.edit().putLong("ad_free_until", newExpiry).apply()
    }

    fun exitAdminMode() {
        _isAdminMode.value = false
    }

    fun enterAdminMode() {
        _isAdminMode.value = true
    }

    fun deactivateLicense() {
        _isPremium.value = false
        _premiumExpiresAt.value = 0L
        _activeKey.value = ""
        prefs.edit()
            .putBoolean("is_premium", false)
            .putLong("premium_expires_at", 0L)
            .remove("active_key")
            .apply()
    }

    fun generateNewKey(days: Int = 30, note: String = ""): String {
        val randomSuffix = UUID.randomUUID().toString().substring(0, 8).uppercase()
        val key = "REALITY-${days}D-$randomSuffix"
        val record = LicenseKeyRecord(key = key, days = days, note = note)
        val updated = _generatedKeys.value.toMutableList()
        updated.add(0, record)
        saveGeneratedKeys(updated)
        return key
    }
}
