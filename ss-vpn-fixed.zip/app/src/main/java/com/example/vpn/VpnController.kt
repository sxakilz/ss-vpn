package com.example.vpn

import android.content.Context
import android.content.Intent
import android.net.VpnService
import androidx.core.content.ContextCompat
import com.example.model.VlessConfig
import kotlinx.coroutines.flow.StateFlow
import org.json.JSONObject

class VpnController(private val context: Context) {

    val status: StateFlow<VpnStatus> = XrayVpnService.status
    val activeServer: StateFlow<VlessConfig?> = XrayVpnService.activeServer
    val trafficStats: StateFlow<TrafficStats> = XrayVpnService.trafficStats
    val logs: StateFlow<List<String>> = XrayVpnService.logs

    /**
     * Checks if VPN permission needs to be requested from user via Activity.
     * Returns the Intent to launch with startActivityForResult, or null if already granted.
     */
    fun prepareVpn(): Intent? {
        return VpnService.prepare(context)
    }

    fun startVpn(server: VlessConfig) {
        val intent = Intent(context, XrayVpnService::class.java).apply {
            action = XrayVpnService.ACTION_CONNECT
            val json = JSONObject().apply {
                put("id", server.id)
                put("remarks", server.remarks)
                put("address", server.address)
                put("port", server.port)
                put("uuid", server.uuid)
                put("flow", server.flow)
                put("security", server.security)
                put("sni", server.sni)
                put("fingerprint", server.fingerprint)
                put("publicKey", server.publicKey)
                put("shortId", server.shortId)
            }
            putExtra(XrayVpnService.EXTRA_SERVER_JSON, json.toString())
        }

        ContextCompat.startForegroundService(context, intent)
    }

    fun stopVpn() {
        val intent = Intent(context, XrayVpnService::class.java).apply {
            action = XrayVpnService.ACTION_DISCONNECT
        }
        context.startService(intent)
    }
}
