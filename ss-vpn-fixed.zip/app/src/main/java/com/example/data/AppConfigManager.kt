package com.example.data

import android.content.Context
import android.provider.Settings
import com.example.vpn.VlessParser
import com.example.vpn.VlessProfile
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

sealed class KeyActivationResult {
    data object AdminUnlocked : KeyActivationResult()
    data class PremiumActivated(val daysLeft: Int) : KeyActivationResult()
    data class Error(val message: String) : KeyActivationResult()
}

data class PremiumKeyData(
    val key: String,
    val days: Int = 30,
    val boundDeviceId: String? = null,
    val activatedAt: Long = 0L,
    val expiresAt: Long = 0L,
    val isRevoked: Boolean = false
)

data class AdMobConfig(
    val bannerId: String = "ca-app-pub-3940256099942544/6300978111",
    val interstitialId: String = "ca-app-pub-3940256099942544/1033173712",
    val rewardedId: String = "ca-app-pub-3940256099942544/5224354917"
)

class AppConfigManager(private val context: Context) {

    private val prefs = context.getSharedPreferences("ss_vpn_config", Context.MODE_PRIVATE)
    private val scope = CoroutineScope(Dispatchers.IO)

    // Hardware Android_ID for 1 Key = 1 Device binding
    val currentDeviceId: String = try {
        Settings.Secure.getString(context.contentResolver, Settings.Secure.ANDROID_ID) ?: "UNKNOWN_DEV"
    } catch (e: Exception) {
        "UNKNOWN_DEV"
    }

    // Default configuration values
    private val defaultAdminKey = "shakilxd71"
    private val defaultVlessUri = "vless://ce5104a4-b697-4d3e-b16e-6d8758bfe400@149.28.156.223:47778?security=reality&encryption=none&pbk=8M89Z5vsKLRa4mXjLPz-huE_qVcQw7hkPX5oj4takFg&headerType=none&fp=chrome&type=tcp&flow=xtls-rprx-vision&sid=c1e22f0e&sni=dl.google.com#SS%20VPN%20Server"

    // StateFlows
    private val _secretAdminKey = MutableStateFlow(defaultAdminKey)
    val secretAdminKey: StateFlow<String> = _secretAdminKey.asStateFlow()

    private val _activeVlessLink = MutableStateFlow(defaultVlessUri)
    val activeVlessLink: StateFlow<String> = _activeVlessLink.asStateFlow()

    private val _currentProfile = MutableStateFlow(VlessProfile.DEFAULT)
    val currentProfile: StateFlow<VlessProfile> = _currentProfile.asStateFlow()

    private val _adMobConfig = MutableStateFlow(AdMobConfig())
    val adMobConfig: StateFlow<AdMobConfig> = _adMobConfig.asStateFlow()

    private val _isPremium = MutableStateFlow(false)
    val isPremium: StateFlow<Boolean> = _isPremium.asStateFlow()

    private val _premiumExpiresAt = MutableStateFlow(0L)
    val premiumExpiresAt: StateFlow<Long> = _premiumExpiresAt.asStateFlow()

    private val _activeKey = MutableStateFlow("")
    val activeKey: StateFlow<String> = _activeKey.asStateFlow()

    private val _adFreeUntil = MutableStateFlow(0L)
    val adFreeUntil: StateFlow<Long> = _adFreeUntil.asStateFlow()

    private val _keysList = MutableStateFlow<List<PremiumKeyData>>(emptyList())
    val keysList: StateFlow<List<PremiumKeyData>> = _keysList.asStateFlow()

    init {
        loadLocalConfig()
        syncWithFirestore()
    }

    private fun loadLocalConfig() {
        _secretAdminKey.value = prefs.getString("secret_admin_key", defaultAdminKey) ?: defaultAdminKey
        val savedVless = prefs.getString("active_vless_uri", defaultVlessUri) ?: defaultVlessUri
        _activeVlessLink.value = savedVless
        val parsed = VlessParser.parse(savedVless).getOrDefault(VlessProfile.DEFAULT)
        _currentProfile.value = parsed

        _adMobConfig.value = AdMobConfig(
            bannerId = prefs.getString("admob_banner", "ca-app-pub-3940256099942544/6300978111") ?: "ca-app-pub-3940256099942544/6300978111",
            interstitialId = prefs.getString("admob_interstitial", "ca-app-pub-3940256099942544/1033173712") ?: "ca-app-pub-3940256099942544/1033173712",
            rewardedId = prefs.getString("admob_rewarded", "ca-app-pub-3940256099942544/5224354917") ?: "ca-app-pub-3940256099942544/5224354917"
        )

        // Check user premium state
        val premium = prefs.getBoolean("is_premium", false)
        val expiry = prefs.getLong("premium_expires_at", 0L)
        val now = System.currentTimeMillis()
        if (premium && expiry > now) {
            _isPremium.value = true
            _premiumExpiresAt.value = expiry
            _activeKey.value = prefs.getString("active_key", "") ?: ""
        } else {
            _isPremium.value = false
            _premiumExpiresAt.value = 0L
        }

        val adFree = prefs.getLong("ad_free_until", 0L)
        _adFreeUntil.value = if (adFree > now) adFree else 0L

        loadKeysRegistry()
    }

    private fun loadKeysRegistry() {
        val json = prefs.getString("keys_registry_json", null)
        val list = mutableListOf<PremiumKeyData>()
        if (!json.isNullOrEmpty()) {
            try {
                val array = JSONArray(json)
                for (i in 0 until array.length()) {
                    val obj = array.getJSONObject(i)
                    list.add(
                        PremiumKeyData(
                            key = obj.getString("key"),
                            days = obj.optInt("days", 30),
                            boundDeviceId = if (obj.has("boundDeviceId") && !obj.isNull("boundDeviceId")) obj.getString("boundDeviceId") else null,
                            activatedAt = obj.optLong("activatedAt", 0L),
                            expiresAt = obj.optLong("expiresAt", 0L),
                            isRevoked = obj.optBoolean("isRevoked", false)
                        )
                    )
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
        _keysList.value = list
    }

    private fun saveKeysRegistry(list: List<PremiumKeyData>) {
        val array = JSONArray()
        list.forEach { k ->
            val obj = JSONObject()
            obj.put("key", k.key)
            obj.put("days", k.days)
            obj.put("boundDeviceId", k.boundDeviceId)
            obj.put("activatedAt", k.activatedAt)
            obj.put("expiresAt", k.expiresAt)
            obj.put("isRevoked", k.isRevoked)
            array.put(obj)
        }
        prefs.edit().putString("keys_registry_json", array.toString()).apply()
        _keysList.value = list
    }

    private fun syncWithFirestore() {
        scope.launch {
            try {
                val db = FirebaseFirestore.getInstance()
                // Sync remote server link
                db.collection("config").document("server").get()
                    .addOnSuccessListener { doc ->
                        val remoteVless = doc.getString("vlessLink")
                        if (!remoteVless.isNullOrEmpty()) {
                            _activeVlessLink.value = remoteVless
                            prefs.edit().putString("active_vless_uri", remoteVless).apply()
                            VlessParser.parse(remoteVless).onSuccess { _currentProfile.value = it }
                        }
                    }

                // Sync remote admin key
                db.collection("config").document("admin").get()
                    .addOnSuccessListener { doc ->
                        val remoteKey = doc.getString("secretAdminKey")
                        if (!remoteKey.isNullOrEmpty()) {
                            _secretAdminKey.value = remoteKey
                            prefs.edit().putString("secret_admin_key", remoteKey).apply()
                        }
                    }

                // Sync remote ad IDs
                db.collection("config").document("ads").get()
                    .addOnSuccessListener { doc ->
                        val banner = doc.getString("bannerId")
                        val interstitial = doc.getString("interstitialId")
                        val rewarded = doc.getString("rewardedId")
                        if (banner != null || interstitial != null || rewarded != null) {
                            val updated = AdMobConfig(
                                bannerId = banner ?: _adMobConfig.value.bannerId,
                                interstitialId = interstitial ?: _adMobConfig.value.interstitialId,
                                rewardedId = rewarded ?: _adMobConfig.value.rewardedId
                            )
                            _adMobConfig.value = updated
                        }
                    }
            } catch (e: Exception) {
                // Silent fallback to local storage
            }
        }
    }

    /**
     * Requirement 4 & 5: Validates key, checks Secret Admin Key, and enforces 1 Key = 1 Device hardware binding.
     */
    fun activateKey(rawInput: String): KeyActivationResult {
        val input = rawInput.trim()
        if (input.isEmpty()) {
            return KeyActivationResult.Error("Please enter an activation key.")
        }

        // 1. Secret Admin Key verification
        if (input == _secretAdminKey.value || input == defaultAdminKey) {
            return KeyActivationResult.AdminUnlocked
        }

        // 2. Premium Key Verification & Device Binding Security
        val registry = _keysList.value.toMutableList()
        val keyData = registry.find { it.key.equals(input, ignoreCase = true) }

        if (keyData == null) {
            return KeyActivationResult.Error("Invalid or expired activation key.")
        }

        if (keyData.isRevoked) {
            return KeyActivationResult.Error("This activation key has been revoked.")
        }

        // Device Binding Check (1 Key = 1 Device Only)
        if (keyData.boundDeviceId != null && keyData.boundDeviceId != currentDeviceId) {
            return KeyActivationResult.Error("Key already activated on another device!")
        }

        // Activate and bind to this device
        val now = System.currentTimeMillis()
        val expiry = if (keyData.expiresAt > now) keyData.expiresAt else now + (keyData.days.toLong() * 24 * 3600 * 1000L)
        val updatedKey = keyData.copy(
            boundDeviceId = currentDeviceId,
            activatedAt = if (keyData.activatedAt > 0) keyData.activatedAt else now,
            expiresAt = expiry
        )

        val index = registry.indexOfFirst { it.key == keyData.key }
        if (index >= 0) registry[index] = updatedKey
        saveKeysRegistry(registry)

        // Save local premium state
        _isPremium.value = true
        _premiumExpiresAt.value = expiry
        _activeKey.value = input

        prefs.edit()
            .putBoolean("is_premium", true)
            .putLong("premium_expires_at", expiry)
            .putString("active_key", input)
            .apply()

        // Sync binding to Firestore
        scope.launch {
            try {
                val db = FirebaseFirestore.getInstance()
                db.collection("keys").document(input).set(
                    mapOf(
                        "key" to input,
                        "boundDeviceId" to currentDeviceId,
                        "activatedAt" to now,
                        "expiresAt" to expiry,
                        "isRevoked" to false
                    )
                )
            } catch (e: Exception) {
                // Fallback saved locally
            }
        }

        val daysLeft = getRemainingPremiumDays()
        return KeyActivationResult.PremiumActivated(daysLeft)
    }

    /**
     * Requirement 6: Stacking +2 hours ad-free access each time watched.
     */
    fun stackTwoHoursAdFree() {
        val now = System.currentTimeMillis()
        val current = _adFreeUntil.value
        val base = if (current > now) current else now
        val newExpiry = base + (2L * 60 * 60 * 1000L) // +2 hours added to existing duration
        _adFreeUntil.value = newExpiry
        prefs.edit().putLong("ad_free_until", newExpiry).apply()
    }

    fun isAdFreeActive(): Boolean {
        if (_isPremium.value && _premiumExpiresAt.value > System.currentTimeMillis()) {
            return true
        }
        return _adFreeUntil.value > System.currentTimeMillis()
    }

    fun getRemainingAdFreeSeconds(): Long {
        val diff = _adFreeUntil.value - System.currentTimeMillis()
        return (diff / 1000L).coerceAtLeast(0L)
    }

    fun getRemainingPremiumDays(): Int {
        val diff = _premiumExpiresAt.value - System.currentTimeMillis()
        if (diff <= 0) return 0
        return ((diff / (1000L * 60 * 60 * 24)) + 1).toInt()
    }

    // Admin Operations
    fun updateSecretAdminKey(newKey: String) {
        val trimmed = newKey.trim()
        if (trimmed.isEmpty()) return
        _secretAdminKey.value = trimmed
        prefs.edit().putString("secret_admin_key", trimmed).apply()
        scope.launch {
            try {
                FirebaseFirestore.getInstance().collection("config").document("admin")
                    .set(mapOf("secretAdminKey" to trimmed))
            } catch (e: Exception) { }
        }
    }

    fun updateActiveVlessLink(newUri: String): Result<VlessProfile> {
        val parsed = VlessParser.parse(newUri)
        if (parsed.isSuccess) {
            val profile = parsed.getOrThrow()
            _activeVlessLink.value = newUri.trim()
            _currentProfile.value = profile
            prefs.edit().putString("active_vless_uri", newUri.trim()).apply()
            scope.launch {
                try {
                    FirebaseFirestore.getInstance().collection("config").document("server")
                        .set(mapOf("vlessLink" to newUri.trim()))
                } catch (e: Exception) { }
            }
            return Result.success(profile)
        }
        return Result.failure(parsed.exceptionOrNull() ?: IllegalArgumentException("Invalid VLESS link"))
    }

    fun updateAdMobIds(banner: String, interstitial: String, rewarded: String) {
        val config = AdMobConfig(
            bannerId = banner.trim(),
            interstitialId = interstitial.trim(),
            rewardedId = rewarded.trim()
        )
        _adMobConfig.value = config
        prefs.edit()
            .putString("admob_banner", config.bannerId)
            .putString("admob_interstitial", config.interstitialId)
            .putString("admob_rewarded", config.rewardedId)
            .apply()
        scope.launch {
            try {
                FirebaseFirestore.getInstance().collection("config").document("ads")
                    .set(
                        mapOf(
                            "bannerId" to config.bannerId,
                            "interstitialId" to config.interstitialId,
                            "rewardedId" to config.rewardedId
                        )
                    )
            } catch (e: Exception) { }
        }
    }

    fun generatePremiumKey(days: Int = 30): String {
        val randomSuffix = UUID.randomUUID().toString().substring(0, 8).uppercase()
        val key = "SS-${days}D-$randomSuffix"
        val newKey = PremiumKeyData(key = key, days = days)
        val list = _keysList.value.toMutableList()
        list.add(0, newKey)
        saveKeysRegistry(list)
        scope.launch {
            try {
                FirebaseFirestore.getInstance().collection("keys").document(key).set(
                    mapOf(
                        "key" to key,
                        "days" to days,
                        "boundDeviceId" to null,
                        "activatedAt" to 0L,
                        "expiresAt" to 0L,
                        "isRevoked" to false
                    )
                )
            } catch (e: Exception) { }
        }
        return key
    }

    fun revokeKey(key: String) {
        val list = _keysList.value.map {
            if (it.key.equals(key, ignoreCase = true)) it.copy(isRevoked = true) else it
        }
        saveKeysRegistry(list)
        if (_activeKey.value.equals(key, ignoreCase = true)) {
            _isPremium.value = false
            _premiumExpiresAt.value = 0L
            _activeKey.value = ""
            prefs.edit().putBoolean("is_premium", false).putLong("premium_expires_at", 0L).remove("active_key").apply()
        }
        scope.launch {
            try {
                FirebaseFirestore.getInstance().collection("keys").document(key).update("isRevoked", true)
            } catch (e: Exception) { }
        }
    }
}
