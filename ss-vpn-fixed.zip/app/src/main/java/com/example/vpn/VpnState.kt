package com.example.vpn

enum class VpnStatus {
    DISCONNECTED,
    CONNECTING,
    CONNECTED,
    DISCONNECTING,
    ERROR
}

data class TrafficStats(
    val uploadSpeedKbps: Float = 0f,
    val downloadSpeedKbps: Float = 0f,
    val totalUploadBytes: Long = 0L,
    val totalDownloadBytes: Long = 0L,
    val durationSeconds: Long = 0L
) {
    fun formatUploadSpeed(): String {
        return if (uploadSpeedKbps > 1024) {
            String.format("%.1f MB/s", uploadSpeedKbps / 1024f)
        } else {
            String.format("%.1f KB/s", uploadSpeedKbps)
        }
    }

    fun formatDownloadSpeed(): String {
        return if (downloadSpeedKbps > 1024) {
            String.format("%.1f MB/s", downloadSpeedKbps / 1024f)
        } else {
            String.format("%.1f KB/s", downloadSpeedKbps)
        }
    }

    fun formatTotalUpload(): String = formatBytes(totalUploadBytes)
    fun formatTotalDownload(): String = formatBytes(totalDownloadBytes)

    fun formatDuration(): String {
        val hours = durationSeconds / 3600
        val minutes = (durationSeconds % 3600) / 60
        val seconds = durationSeconds % 60
        return if (hours > 0) {
            String.format("%02d:%02d:%02d", hours, minutes, seconds)
        } else {
            String.format("%02d:%02d", minutes, seconds)
        }
    }

    companion object {
        fun formatBytes(bytes: Long): String {
            if (bytes < 1024) return "$bytes B"
            val exp = (Math.log(bytes.toDouble()) / Math.log(1024.0)).toInt()
            val pre = "KMGTPE"[exp - 1]
            return String.format("%.2f %sB", bytes / Math.pow(1024.0, exp.toDouble()), pre)
        }
    }
}
