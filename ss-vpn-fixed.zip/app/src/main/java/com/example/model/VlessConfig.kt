package com.example.model

import android.net.Uri
import java.net.URLDecoder
import java.net.URLEncoder
import java.nio.charset.StandardCharsets

/**
 * Data model for a VLESS + REALITY connection profile.
 */
data class VlessConfig(
    val id: String = java.util.UUID.randomUUID().toString(),
    val remarks: String = "Reality Server",
    val address: String,
    val port: Int = 443,
    val uuid: String,
    val flow: String = "xtls-rprx-vision",
    val encryption: String = "none",
    val networkType: String = "tcp", // tcp, grpc, ws
    val headerType: String = "none",
    val security: String = "reality",
    val sni: String = "",
    val fingerprint: String = "chrome",
    val publicKey: String = "",
    val shortId: String = "",
    val spiderX: String = "/",
    val pingMs: Int = -1,
    val isCustom: Boolean = false
) {
    /**
     * Converts this configuration back to a standard VLESS URI string.
     */
    fun toVlessUri(): String {
        val queryParams = mutableListOf<String>()
        queryParams.add("security=$security")
        if (sni.isNotEmpty()) queryParams.add("sni=${encode(sni)}")
        if (fingerprint.isNotEmpty()) queryParams.add("fp=${encode(fingerprint)}")
        if (publicKey.isNotEmpty()) queryParams.add("pbk=${encode(publicKey)}")
        if (shortId.isNotEmpty()) queryParams.add("sid=${encode(shortId)}")
        if (flow.isNotEmpty()) queryParams.add("flow=${encode(flow)}")
        if (networkType.isNotEmpty()) queryParams.add("type=${encode(networkType)}")
        if (headerType.isNotEmpty() && headerType != "none") queryParams.add("headerType=${encode(headerType)}")
        if (spiderX.isNotEmpty() && spiderX != "/") queryParams.add("spx=${encode(spiderX)}")
        if (encryption.isNotEmpty() && encryption != "none") queryParams.add("encryption=${encode(encryption)}")

        val query = queryParams.joinToString("&")
        val remarkEncoded = encode(remarks)
        return "vless://$uuid@$address:$port?$query#$remarkEncoded"
    }

    /**
     * Exports this configuration to standard Xray client JSON format.
     */
    fun toXrayConfigJson(localSocksPort: Int = 10808, localHttpPort: Int = 10809): String {
        return """
        {
          "log": {
            "loglevel": "warning"
          },
          "inbounds": [
            {
              "tag": "socks-in",
              "port": $localSocksPort,
              "listen": "127.0.0.1",
              "protocol": "socks",
              "settings": {
                "auth": "noauth",
                "udp": true
              }
            },
            {
              "tag": "http-in",
              "port": $localHttpPort,
              "listen": "127.0.0.1",
              "protocol": "http"
            }
          ],
          "outbounds": [
            {
              "tag": "proxy",
              "protocol": "vless",
              "settings": {
                "vnext": [
                  {
                    "address": "$address",
                    "port": $port,
                    "users": [
                      {
                        "id": "$uuid",
                        "encryption": "$encryption",
                        "flow": "$flow"
                      }
                    ]
                  }
                ]
              },
              "streamSettings": {
                "network": "$networkType",
                "security": "$security",
                "realitySettings": {
                  "show": false,
                  "fingerprint": "$fingerprint",
                  "serverName": "$sni",
                  "publicKey": "$publicKey",
                  "shortId": "$shortId",
                  "spiderX": "$spiderX"
                }
              }
            },
            {
              "tag": "direct",
              "protocol": "freedom"
            },
            {
              "tag": "block",
              "protocol": "blackhole"
            }
          ]
        }
        """.trimIndent()
    }

    companion object {
        private fun encode(value: String): String =
            URLEncoder.encode(value, StandardCharsets.UTF_8.toString())

        private fun decode(value: String): String =
            try {
                URLDecoder.decode(value, StandardCharsets.UTF_8.toString())
            } catch (e: Exception) {
                value
            }

        /**
         * Parses a VLESS URI string into a VlessConfig object.
         * Example: vless://UUID@HOST:PORT?security=reality&sni=example.com&fp=chrome&pbk=PBK&sid=SID&flow=xtls-rprx-vision#MyServer
         */
        fun parse(uriString: String): Result<VlessConfig> {
            val trimmed = uriString.trim()
            if (!trimmed.startsWith("vless://", ignoreCase = true)) {
                return Result.failure(IllegalArgumentException("Invalid VLESS link: must start with 'vless://'"))
            }

            return try {
                val withoutScheme = trimmed.substring("vless://".length)
                val parts = withoutScheme.split("#", limit = 2)
                val coreAndQuery = parts[0]
                val remarks = if (parts.size > 1 && parts[1].isNotEmpty()) {
                    decode(parts[1])
                } else {
                    "Reality Server"
                }

                val atIndex = coreAndQuery.indexOf('@')
                if (atIndex == -1) {
                    return Result.failure(IllegalArgumentException("Missing UUID or server address in VLESS link"))
                }

                val uuid = coreAndQuery.substring(0, atIndex).trim()

                val rest = coreAndQuery.substring(atIndex + 1)
                val questionIndex = rest.indexOf('?')
                val hostPort = if (questionIndex != -1) rest.substring(0, questionIndex) else rest
                val queryString = if (questionIndex != -1) rest.substring(questionIndex + 1) else ""

                val hostPortParts = hostPort.split(":")
                val host = hostPortParts[0].trim()
                val port = if (hostPortParts.size > 1) {
                    hostPortParts[1].toIntOrNull() ?: 443
                } else {
                    443
                }

                val params = mutableMapOf<String, String>()
                if (queryString.isNotEmpty()) {
                    queryString.split("&").forEach { pair ->
                        val kv = pair.split("=", limit = 2)
                        if (kv.isNotEmpty()) {
                            val key = kv[0].lowercase().trim()
                            val value = if (kv.size > 1) decode(kv[1].trim()) else ""
                            params[key] = value
                        }
                    }
                }

                val security = params["security"] ?: "reality"
                val sni = params["sni"] ?: params["serverName"] ?: host
                val fingerprint = params["fp"] ?: "chrome"
                val publicKey = params["pbk"] ?: ""
                val shortId = params["sid"] ?: ""
                val flow = params["flow"] ?: "xtls-rprx-vision"
                val networkType = params["type"] ?: "tcp"
                val headerType = params["headertype"] ?: "none"
                val encryption = params["encryption"] ?: "none"
                val spiderX = params["spx"] ?: "/"

                if (uuid.isEmpty() || host.isEmpty()) {
                    return Result.failure(IllegalArgumentException("Invalid VLESS configuration: UUID and host are required"))
                }

                Result.success(
                    VlessConfig(
                        remarks = remarks,
                        address = host,
                        port = port,
                        uuid = uuid,
                        flow = flow,
                        encryption = encryption,
                        networkType = networkType,
                        headerType = headerType,
                        security = security,
                        sni = sni,
                        fingerprint = fingerprint,
                        publicKey = publicKey,
                        shortId = shortId,
                        spiderX = spiderX,
                        isCustom = true
                    )
                )
            } catch (e: Exception) {
                Result.failure(IllegalArgumentException("Failed to parse VLESS URI: ${e.message}", e))
            }
        }
    }
}
