package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Pure White Canvas & Crisp Modern Accents
val White = Color(0xFFFFFFFF)
val SurfaceCard = Color(0xFFFAFAFC)
val SurfaceCardHover = Color(0xFFF1F5F9)
val BorderLight = Color(0xFFE2E8F0)
val BorderSubtle = Color(0xFFEDF2F7)

// Brand Primary & Accents
val BrandPrimary = Color(0xFF0F62FE)
val BrandPrimaryDark = Color(0xFF0043CE)
val BrandSecondary = Color(0xFF0090FF)
val BrandAccent = Color(0xFF00C7BE)

// Status Colors
val StatusConnected = Color(0xFF10B981)
val StatusConnectedBg = Color(0xFFECFDF5)
val StatusDisconnected = Color(0xFFEF4444)
val StatusDisconnectedBg = Color(0xFFFEF2F2)
val StatusConnecting = Color(0xFFF59E0B)
val StatusConnectingBg = Color(0xFFFFFBEB)

// Typography & Text
val TextPrimary = Color(0xFF0F172A)
val TextSecondary = Color(0xFF475569)
val TextMuted = Color(0xFF94A3B8)

// Admin Gold / Amber
val AdminGold = Color(0xFFD97706)
val AdminGoldBg = Color(0xFFFEF3C7)
val PremiumPurple = Color(0xFF7C3AED)
val PremiumPurpleBg = Color(0xFFF5F3FF)
