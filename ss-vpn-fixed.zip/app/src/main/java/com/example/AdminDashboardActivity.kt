package com.example

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.Block
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.ContentPaste
import androidx.compose.material.icons.filled.Dns
import androidx.compose.material.icons.filled.Error
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.MonetizationOn
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Router
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import com.example.core.ConfigManager
import com.example.core.MyVpnService
import com.example.core.VpnLeakDiagnostic
import com.example.vpn.VpnStatus
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.AppConfigManager
import com.example.ui.theme.MyApplicationTheme

class AdminDashboardActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        val appConfigManager = RealityVpnApp.instance.appConfigManager

        setContent {
            MyApplicationTheme {
                AdminDashboardContent(
                    appConfigManager = appConfigManager,
                    onBack = { finish() }
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminDashboardContent(
    appConfigManager: AppConfigManager,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    var selectedTab by remember { mutableIntStateOf(0) }

    val adminKey by appConfigManager.secretAdminKey.collectAsState()
    val activeVless by appConfigManager.activeVlessLink.collectAsState()
    val adMobConfig by appConfigManager.adMobConfig.collectAsState()
    val keysList by appConfigManager.keysList.collectAsState()

    // Form states
    var newAdminKeyInput by remember(adminKey) { mutableStateOf(adminKey) }
    var vlessInput by remember(activeVless) { mutableStateOf(activeVless) }
    var bannerIdInput by remember(adMobConfig) { mutableStateOf(adMobConfig.bannerId) }
    var interstitialIdInput by remember(adMobConfig) { mutableStateOf(adMobConfig.interstitialId) }
    var rewardedIdInput by remember(adMobConfig) { mutableStateOf(adMobConfig.rewardedId) }
    var lastGeneratedKey by remember { mutableStateOf<String?>(null) }

    Scaffold(
        modifier = Modifier
            .fillMaxSize()
            .testTag("admin_dashboard_activity"),
        containerColor = Color.White,
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(32.dp)
                                .clip(CircleShape)
                                .background(Color(0xFFFEF3C7)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.AdminPanelSettings,
                                contentDescription = null,
                                tint = Color(0xFFD97706),
                                modifier = Modifier.size(20.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "SS VPN Admin Console",
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF0F172A)
                            )
                            Text(
                                text = "Remote Control & License Manager",
                                fontSize = 11.sp,
                                color = Color(0xFF64748B)
                            )
                        }
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                            tint = Color(0xFF0F172A)
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.White)
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(Color.White)
        ) {
            // Secret Admin Status Header
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 6.dp)
                    .clip(RoundedCornerShape(24.dp))
                    .background(Color(0xFFF8F9FA))
                    .border(1.dp, Color(0xFFE2E8F0), RoundedCornerShape(24.dp))
                    .padding(14.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Security,
                        contentDescription = null,
                        tint = Color(0xFF10B981),
                        modifier = Modifier.size(22.dp)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = "Authenticated as admin",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF0F172A)
                        )
                        Text(
                            text = "Syncs automatically with Firebase project 'shakilsiddiq-vpn'",
                            fontSize = 11.sp,
                            color = Color(0xFF64748B)
                        )
                    }
                }
            }

            // Tab Navigation
            ScrollableTabRow(
                selectedTabIndex = selectedTab,
                edgePadding = 12.dp,
                containerColor = Color.White,
                contentColor = Color(0xFF0F62FE),
                indicator = { tabPositions ->
                    TabRowDefaults.SecondaryIndicator(
                        Modifier.tabIndicatorOffset(tabPositions[selectedTab]),
                        color = Color(0xFF0F62FE)
                    )
                }
            ) {
                Tab(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    text = { Text("Licenses", fontSize = 13.sp, fontWeight = FontWeight.SemiBold) }
                )
                Tab(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    text = { Text("VLESS Link", fontSize = 13.sp, fontWeight = FontWeight.SemiBold) }
                )
                Tab(
                    selected = selectedTab == 2,
                    onClick = { selectedTab = 2 },
                    text = { Text("AdMob IDs", fontSize = 13.sp, fontWeight = FontWeight.SemiBold) }
                )
                Tab(
                    selected = selectedTab == 3,
                    onClick = { selectedTab = 3 },
                    text = { Text("Admin Key", fontSize = 13.sp, fontWeight = FontWeight.SemiBold) }
                )
                Tab(
                    selected = selectedTab == 4,
                    onClick = { selectedTab = 4 },
                    text = {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Security,
                                contentDescription = null,
                                tint = if (selectedTab == 4) Color(0xFF10B981) else Color(0xFF64748B),
                                modifier = Modifier.size(15.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                "Leak Diagnostic",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (selectedTab == 4) Color(0xFF10B981) else Color(0xFF0F172A)
                            )
                        }
                    }
                )
            }

            when (selectedTab) {
                0 -> {
                    // d) Generate and revoke 1-Month Premium License Keys
                    LazyColumn(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        item {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(24.dp))
                                    .background(Color(0xFFF8F9FA))
                                    .border(1.dp, Color(0xFFE2E8F0), RoundedCornerShape(24.dp))
                                    .padding(16.dp)
                            ) {
                                Column {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(
                                            imageVector = Icons.Default.Key,
                                            contentDescription = null,
                                            tint = Color(0xFF0F62FE),
                                            modifier = Modifier.size(20.dp)
                                        )
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text(
                                            text = "Generate 1-Month Premium Key",
                                            fontSize = 15.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = Color(0xFF0F172A)
                                        )
                                    }

                                    Spacer(modifier = Modifier.height(8.dp))

                                    Text(
                                        text = "Keys enforce 1-device binding. Valid for 30 days from activation.",
                                        fontSize = 12.sp,
                                        color = Color(0xFF64748B)
                                    )

                                    Spacer(modifier = Modifier.height(14.dp))

                                    Button(
                                        onClick = {
                                            val key = appConfigManager.generatePremiumKey(30)
                                            lastGeneratedKey = key
                                            val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                            clipboard.setPrimaryClip(ClipData.newPlainText("License Key", key))
                                            Toast.makeText(context, "Key Generated & Copied: $key", Toast.LENGTH_SHORT).show()
                                        },
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .height(46.dp)
                                            .testTag("admin_generate_key_btn"),
                                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0F62FE)),
                                        shape = RoundedCornerShape(14.dp)
                                    ) {
                                        Icon(imageVector = Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text("Create 1-Month Key (30 Days)", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                    }

                                    if (lastGeneratedKey != null) {
                                        Spacer(modifier = Modifier.height(12.dp))
                                        Box(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .clip(RoundedCornerShape(12.dp))
                                                .background(Color(0xFFECFDF5))
                                                .border(1.dp, Color(0xFFA7F3D0), RoundedCornerShape(12.dp))
                                                .padding(12.dp)
                                        ) {
                                            Row(
                                                modifier = Modifier.fillMaxWidth(),
                                                horizontalArrangement = Arrangement.SpaceBetween,
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Column {
                                                    Text(text = "New Key Ready:", fontSize = 10.sp, color = Color(0xFF065F46))
                                                    Text(
                                                        text = lastGeneratedKey ?: "",
                                                        fontSize = 14.sp,
                                                        fontWeight = FontWeight.Bold,
                                                        fontFamily = FontFamily.Monospace,
                                                        color = Color(0xFF047857)
                                                    )
                                                }
                                                IconButton(
                                                    onClick = {
                                                        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                                        clipboard.setPrimaryClip(ClipData.newPlainText("License Key", lastGeneratedKey ?: ""))
                                                        Toast.makeText(context, "Copied to clipboard", Toast.LENGTH_SHORT).show()
                                                    }
                                                ) {
                                                    Icon(imageVector = Icons.Default.ContentCopy, contentDescription = "Copy", tint = Color(0xFF047857))
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }

                        item {
                            Text(
                                text = "Active & Generated Keys (${keysList.size})",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF0F172A)
                            )
                        }

                        items(keysList) { keyItem ->
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(16.dp))
                                    .background(Color(0xFFF8F9FA))
                                    .border(1.dp, Color(0xFFE2E8F0), RoundedCornerShape(16.dp))
                                    .padding(14.dp)
                            ) {
                                Column {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = keyItem.key,
                                            fontSize = 13.sp,
                                            fontWeight = FontWeight.Bold,
                                            fontFamily = FontFamily.Monospace,
                                            color = Color(0xFF0F172A)
                                        )

                                        Box(
                                            modifier = Modifier
                                                .clip(RoundedCornerShape(6.dp))
                                                .background(
                                                    when {
                                                        keyItem.isRevoked -> Color(0xFFFEE2E2)
                                                        keyItem.boundDeviceId != null -> Color(0xFFECFDF5)
                                                        else -> Color(0xFFEFF6FF)
                                                    }
                                                )
                                                .padding(horizontal = 8.dp, vertical = 3.dp)
                                        ) {
                                            Text(
                                                text = when {
                                                    keyItem.isRevoked -> "REVOKED"
                                                    keyItem.boundDeviceId != null -> "BOUND"
                                                    else -> "AVAILABLE"
                                                },
                                                fontSize = 10.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = when {
                                                    keyItem.isRevoked -> Color(0xFFDC2626)
                                                    keyItem.boundDeviceId != null -> Color(0xFF10B981)
                                                    else -> Color(0xFF0F62FE)
                                                }
                                            )
                                        }
                                    }

                                    Spacer(modifier = Modifier.height(4.dp))

                                    Text(
                                        text = if (keyItem.boundDeviceId != null) "Bound Device: ${keyItem.boundDeviceId}" else "Unbound (Awaiting device)",
                                        fontSize = 11.sp,
                                        color = Color(0xFF64748B)
                                    )

                                    Spacer(modifier = Modifier.height(8.dp))

                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.End,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        IconButton(
                                            onClick = {
                                                val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                                clipboard.setPrimaryClip(ClipData.newPlainText("License Key", keyItem.key))
                                                Toast.makeText(context, "Copied ${keyItem.key}", Toast.LENGTH_SHORT).show()
                                            },
                                            modifier = Modifier.size(32.dp)
                                        ) {
                                            Icon(imageVector = Icons.Default.ContentCopy, contentDescription = "Copy", tint = Color(0xFF64748B))
                                        }

                                        if (!keyItem.isRevoked) {
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Button(
                                                onClick = {
                                                    appConfigManager.revokeKey(keyItem.key)
                                                    Toast.makeText(context, "Revoked: ${keyItem.key}", Toast.LENGTH_SHORT).show()
                                                },
                                                colors = ButtonDefaults.buttonColors(
                                                    containerColor = Color(0xFFFEE2E2),
                                                    contentColor = Color(0xFFDC2626)
                                                ),
                                                shape = RoundedCornerShape(10.dp),
                                                modifier = Modifier.height(30.dp)
                                            ) {
                                                Icon(imageVector = Icons.Default.Block, contentDescription = null, modifier = Modifier.size(12.dp))
                                                Spacer(modifier = Modifier.width(4.dp))
                                                Text("Revoke", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                1 -> {
                    // b) Update active VLESS Server Link (Syncs with Firebase Firestore)
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(16.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(24.dp))
                                .background(Color(0xFFF8F9FA))
                                .border(1.dp, Color(0xFFE2E8F0), RoundedCornerShape(24.dp))
                                .padding(16.dp)
                        ) {
                            Column {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        imageVector = Icons.Default.Dns,
                                        contentDescription = null,
                                        tint = Color(0xFF0F62FE),
                                        modifier = Modifier.size(20.dp)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = "Active VLESS Reality Node",
                                        fontSize = 15.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color(0xFF0F172A)
                                    )
                                }

                                Spacer(modifier = Modifier.height(8.dp))

                                Text(
                                    text = "Changes are synced in real-time to Firebase Firestore under collection 'config/server' and propagate to all active clients.",
                                    fontSize = 12.sp,
                                    color = Color(0xFF64748B)
                                )

                                Spacer(modifier = Modifier.height(14.dp))

                                OutlinedTextField(
                                    value = vlessInput,
                                    onValueChange = { vlessInput = it },
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .testTag("admin_vless_input"),
                                    label = { Text("VLESS URI") },
                                    trailingIcon = {
                                        IconButton(
                                            onClick = {
                                                val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                                val clip = clipboard.primaryClip
                                                if (clip != null && clip.itemCount > 0) {
                                                    val text = clip.getItemAt(0).text?.toString() ?: ""
                                                    vlessInput = text.trim()
                                                }
                                            }
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.ContentPaste,
                                                contentDescription = "Paste",
                                                tint = Color(0xFF0F62FE)
                                            )
                                        }
                                    },
                                    minLines = 3,
                                    maxLines = 5,
                                    colors = OutlinedTextFieldDefaults.colors(
                                        focusedContainerColor = Color.White,
                                        unfocusedContainerColor = Color.White,
                                        focusedBorderColor = Color(0xFF0F62FE),
                                        unfocusedBorderColor = Color(0xFFE2E8F0)
                                    ),
                                    shape = RoundedCornerShape(12.dp)
                                )

                                Spacer(modifier = Modifier.height(14.dp))

                                Button(
                                    onClick = {
                                        val result = appConfigManager.updateActiveVlessLink(vlessInput)
                                        if (result.isSuccess) {
                                            Toast.makeText(context, "Active VLESS Link Saved & Synced to Firestore!", Toast.LENGTH_SHORT).show()
                                        } else {
                                            Toast.makeText(context, result.exceptionOrNull()?.message ?: "Invalid VLESS Link", Toast.LENGTH_LONG).show()
                                        }
                                    },
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(46.dp)
                                        .testTag("admin_save_vless_btn"),
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0F62FE)),
                                    shape = RoundedCornerShape(12.dp)
                                ) {
                                    Icon(imageVector = Icons.Default.Save, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Save & Sync to Firestore", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
                2 -> {
                    // c) Update AdMob IDs (Banner ID, Interstitial ID, Rewarded Ad ID)
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(16.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(24.dp))
                                .background(Color(0xFFF8F9FA))
                                .border(1.dp, Color(0xFFE2E8F0), RoundedCornerShape(24.dp))
                                .padding(16.dp)
                        ) {
                            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        imageVector = Icons.Default.MonetizationOn,
                                        contentDescription = null,
                                        tint = Color(0xFF0F62FE),
                                        modifier = Modifier.size(20.dp)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = "AdMob Monetization Units",
                                        fontSize = 15.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color(0xFF0F172A)
                                    )
                                }

                                Text(
                                    text = "Update live production AdMob ad unit IDs. Synced with Firestore 'config/ads'.",
                                    fontSize = 12.sp,
                                    color = Color(0xFF64748B)
                                )

                                OutlinedTextField(
                                    value = bannerIdInput,
                                    onValueChange = { bannerIdInput = it },
                                    label = { Text("Banner Ad Unit ID") },
                                    modifier = Modifier.fillMaxWidth(),
                                    singleLine = true,
                                    colors = OutlinedTextFieldDefaults.colors(
                                        focusedContainerColor = Color.White,
                                        unfocusedContainerColor = Color.White,
                                        focusedBorderColor = Color(0xFF0F62FE),
                                        unfocusedBorderColor = Color(0xFFE2E8F0)
                                    ),
                                    shape = RoundedCornerShape(12.dp)
                                )

                                OutlinedTextField(
                                    value = interstitialIdInput,
                                    onValueChange = { interstitialIdInput = it },
                                    label = { Text("Interstitial Ad Unit ID") },
                                    modifier = Modifier.fillMaxWidth(),
                                    singleLine = true,
                                    colors = OutlinedTextFieldDefaults.colors(
                                        focusedContainerColor = Color.White,
                                        unfocusedContainerColor = Color.White,
                                        focusedBorderColor = Color(0xFF0F62FE),
                                        unfocusedBorderColor = Color(0xFFE2E8F0)
                                    ),
                                    shape = RoundedCornerShape(12.dp)
                                )

                                OutlinedTextField(
                                    value = rewardedIdInput,
                                    onValueChange = { rewardedIdInput = it },
                                    label = { Text("Rewarded Ad Unit ID") },
                                    modifier = Modifier.fillMaxWidth(),
                                    singleLine = true,
                                    colors = OutlinedTextFieldDefaults.colors(
                                        focusedContainerColor = Color.White,
                                        unfocusedContainerColor = Color.White,
                                        focusedBorderColor = Color(0xFF0F62FE),
                                        unfocusedBorderColor = Color(0xFFE2E8F0)
                                    ),
                                    shape = RoundedCornerShape(12.dp)
                                )

                                Button(
                                    onClick = {
                                        appConfigManager.updateAdMobIds(bannerIdInput, interstitialIdInput, rewardedIdInput)
                                        Toast.makeText(context, "AdMob IDs updated and synced!", Toast.LENGTH_SHORT).show()
                                    },
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(46.dp)
                                        .testTag("admin_save_admob_btn"),
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0F62FE)),
                                    shape = RoundedCornerShape(12.dp)
                                ) {
                                    Icon(imageVector = Icons.Default.Save, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Save Ad Units", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
                3 -> {
                    // a) Update Secret Admin Key
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(16.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(24.dp))
                                .background(Color(0xFFF8F9FA))
                                .border(1.dp, Color(0xFFE2E8F0), RoundedCornerShape(24.dp))
                                .padding(16.dp)
                        ) {
                            Column {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        imageVector = Icons.Default.AdminPanelSettings,
                                        contentDescription = null,
                                        tint = Color(0xFFD97706),
                                        modifier = Modifier.size(20.dp)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = "Secret Admin Access Key",
                                        fontSize = 15.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color(0xFF0F172A)
                                    )
                                }

                                Spacer(modifier = Modifier.height(8.dp))

                                Text(
                                    text = "Current key opens this hidden console when entered in the activation box.",
                                    fontSize = 12.sp,
                                    color = Color(0xFF64748B)
                                )

                                Spacer(modifier = Modifier.height(14.dp))

                                OutlinedTextField(
                                    value = newAdminKeyInput,
                                    onValueChange = { newAdminKeyInput = it },
                                    label = { Text("Secret Admin Password") },
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .testTag("admin_new_key_input"),
                                    singleLine = true,
                                    colors = OutlinedTextFieldDefaults.colors(
                                        focusedContainerColor = Color.White,
                                        unfocusedContainerColor = Color.White,
                                        focusedBorderColor = Color(0xFF0F62FE),
                                        unfocusedBorderColor = Color(0xFFE2E8F0)
                                    ),
                                    shape = RoundedCornerShape(12.dp)
                                )

                                Spacer(modifier = Modifier.height(14.dp))

                                Button(
                                    onClick = {
                                        appConfigManager.updateSecretAdminKey(newAdminKeyInput)
                                        Toast.makeText(context, "Admin Key Updated!", Toast.LENGTH_SHORT).show()
                                    },
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(46.dp)
                                        .testTag("admin_save_key_btn"),
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0F62FE)),
                                    shape = RoundedCornerShape(12.dp),
                                    enabled = newAdminKeyInput.isNotBlank()
                                ) {
                                    Icon(imageVector = Icons.Default.Save, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Update Admin Key", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
                4 -> {
                    // e) Automated VPN Traffic Leak Diagnostic & Auto-Fix Engine
                    LeakDiagnosticTabContent(
                        appConfigManager = appConfigManager,
                        context = context
                    )
                }
            }
        }
    }
}

@Composable
fun LeakDiagnosticTabContent(
    appConfigManager: com.example.data.AppConfigManager,
    context: Context
) {
    val activeVlessUri by appConfigManager.activeVlessLink.collectAsState()
    val currentProfile by appConfigManager.currentProfile.collectAsState()
    val vpnStatus by MyVpnService.vpnStatus.collectAsState()
    val activeOutboundTag by MyVpnService.activeOutboundTag.collectAsState()
    val livePing by MyVpnService.pingMs.collectAsState()

    val configManager = remember { ConfigManager(context) }
    var diagnosticReport by remember {
        mutableStateOf<VpnLeakDiagnostic.DiagnosticReport?>(null)
    }
    var handshakeResult by remember { mutableStateOf<String?>(null) }
    var isAuditing by remember { mutableStateOf(false) }

    // Coroutine scope for running async audits & socket handshake tests
    val scope = remember { CoroutineScope(Dispatchers.Main) }

    // Run audit automatically on composition
    androidx.compose.runtime.LaunchedEffect(activeVlessUri, activeOutboundTag, vpnStatus) {
        val singboxJson = configManager.buildSingboxConfigJson(currentProfile)
        diagnosticReport = VpnLeakDiagnostic.runAudit(
            configJson = singboxJson,
            activeProfile = currentProfile,
            isVpnActive = vpnStatus == VpnStatus.CONNECTED,
            activeOutboundTag = activeOutboundTag
        )
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .testTag("admin_leak_diagnostic_tab"),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // 1. Overall Status Card
        item {
            val report = diagnosticReport
            val isZeroLeak = report?.isZeroLeakGuaranteed == true

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(24.dp))
                    .background(if (isZeroLeak) Color(0xFFECFDF5) else Color(0xFFFEF2F2))
                    .border(
                        1.dp,
                        if (isZeroLeak) Color(0xFFA7F3D0) else Color(0xFFFECACA),
                        RoundedCornerShape(24.dp)
                    )
                    .padding(18.dp)
            ) {
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = if (isZeroLeak) Icons.Default.CheckCircle else Icons.Default.Error,
                                contentDescription = null,
                                tint = if (isZeroLeak) Color(0xFF10B981) else Color(0xFFEF4444),
                                modifier = Modifier.size(24.dp)
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(
                                    text = if (isZeroLeak) "ZERO-LEAK GUARANTEED" else "LEAK DETECTED: DUBAI IP EXPOSED",
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (isZeroLeak) Color(0xFF065F46) else Color(0xFF991B1B)
                                )
                                Text(
                                    text = if (isZeroLeak)
                                        "100% of global traffic strictly routed via VLESS Reality tag 'proxy'"
                                    else
                                        (report?.errorStatusSummary ?: "Route fallback is set to DIRECT instead of PROXY!"),
                                    fontSize = 12.sp,
                                    color = if (isZeroLeak) Color(0xFF047857) else Color(0xFFB91C1C)
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Gateway Telemetry Row
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(Color.White.copy(alpha = 0.85f))
                            .padding(10.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text("Target VPS", fontSize = 10.sp, color = Color(0xFF64748B), fontWeight = FontWeight.SemiBold)
                            Text("${currentProfile.address}:${currentProfile.port}", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color(0xFF0F172A))
                        }
                        Column {
                            Text("Outbound Tag", fontSize = 10.sp, color = Color(0xFF64748B), fontWeight = FontWeight.SemiBold)
                            Text(activeOutboundTag, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = if (activeOutboundTag == "proxy") Color(0xFF10B981) else Color(0xFFEF4444))
                        }
                        Column {
                            Text("TUN Gateway", fontSize = 10.sp, color = Color(0xFF64748B), fontWeight = FontWeight.SemiBold)
                            Text("172.19.0.1/30", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color(0xFF0F172A))
                        }
                        Column {
                            Text("Live Ping", fontSize = 10.sp, color = Color(0xFF64748B), fontWeight = FontWeight.SemiBold)
                            Text(if (livePing > 0) "$livePing ms" else "-- ms", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color(0xFF0F62FE))
                        }
                    }
                }
            }
        }

        // 2. Action Control Buttons: Run Audit & Fix This Routine
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // "Run Deep Audit" Button
                Button(
                    onClick = {
                        isAuditing = true
                        val singboxJson = configManager.buildSingboxConfigJson(currentProfile)
                        diagnosticReport = VpnLeakDiagnostic.runAudit(
                            configJson = singboxJson,
                            activeProfile = currentProfile,
                            isVpnActive = vpnStatus == VpnStatus.CONNECTED,
                            activeOutboundTag = activeOutboundTag
                        )
                        isAuditing = false
                        Toast.makeText(context, "Audit Completed: ${diagnosticReport?.findings?.size ?: 0} checks performed", Toast.LENGTH_SHORT).show()
                    },
                    modifier = Modifier
                        .weight(1f)
                        .height(46.dp)
                        .testTag("admin_run_audit_btn"),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0F172A)),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(imageVector = Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Run Audit", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }

                // "Fix This" Routine / Dynamic JSON Patcher Button
                Button(
                    onClick = {
                        val currentJson = configManager.buildSingboxConfigJson(currentProfile)
                        val fixResult = VpnLeakDiagnostic.applyAutoFix(currentJson, currentProfile)
                        if (fixResult.success) {
                            MyVpnService.setOutboundTag("proxy")
                            diagnosticReport = VpnLeakDiagnostic.runAudit(
                                configJson = fixResult.patchedJson,
                                activeProfile = currentProfile,
                                isVpnActive = vpnStatus == VpnStatus.CONNECTED,
                                activeOutboundTag = "proxy"
                            )
                            Toast.makeText(context, "✅ Fix Applied: Route fallback locked to PROXY!", Toast.LENGTH_LONG).show()
                        } else {
                            Toast.makeText(context, "Fix failed: ${fixResult.summaryMessage}", Toast.LENGTH_SHORT).show()
                        }
                    },
                    modifier = Modifier
                        .weight(1f)
                        .height(46.dp)
                        .testTag("admin_fix_this_btn"),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF10B981)),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(imageVector = Icons.Default.Build, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Fix This", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }
        }

        // 3. Socket Handshake Verification Test Button
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(20.dp))
                    .background(Color(0xFFF8F9FA))
                    .border(1.dp, Color(0xFFE2E8F0), RoundedCornerShape(20.dp))
                    .padding(14.dp)
            ) {
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(imageVector = Icons.Default.Router, contentDescription = null, tint = Color(0xFF0F62FE), modifier = Modifier.size(20.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("VPS Socket Handshake Test", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Color(0xFF0F172A))
                        }

                        Button(
                            onClick = {
                                scope.launch {
                                    handshakeResult = "Testing socket connection to ${currentProfile.address}:${currentProfile.port}..."
                                    val (success, latency) = withContext(Dispatchers.IO) {
                                        VpnLeakDiagnostic.testVpsSocketHandshake(
                                            vpnService = MyVpnService.currentInstance,
                                            serverIp = currentProfile.address,
                                            serverPort = currentProfile.port,
                                            timeoutMs = 4000
                                        )
                                    }
                                    handshakeResult = if (success) {
                                        "SUCCESS: Socket handshake verified in $latency ms (Protected outbound, no TUN self-loop)."
                                    } else {
                                        "FAILED: Unable to reach ${currentProfile.address}:${currentProfile.port} within 4000ms."
                                    }
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0F62FE)),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.height(36.dp)
                        ) {
                            Icon(imageVector = Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Test (4s)", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    if (!handshakeResult.isNullOrEmpty()) {
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = handshakeResult ?: "",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Medium,
                            color = if (handshakeResult?.startsWith("SUCCESS") == true) Color(0xFF047857) else Color(0xFFB91C1C)
                        )
                    }
                }
            }
        }

        // 4. Detailed Component Audit Findings
        item {
            Text(
                text = "Automated Component Audit",
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF0F172A)
            )
        }

        val findings = diagnosticReport?.findings ?: emptyList()
        items(findings) { finding ->
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(Color(0xFFF8F9FA))
                    .border(
                        1.dp,
                        when (finding.severity) {
                            VpnLeakDiagnostic.Severity.ERROR -> Color(0xFFFECACA)
                            VpnLeakDiagnostic.Severity.WARNING -> Color(0xFFFED7AA)
                            VpnLeakDiagnostic.Severity.INFO -> Color(0xFFE2E8F0)
                        },
                        RoundedCornerShape(16.dp)
                    )
                    .padding(14.dp)
            ) {
                Row(verticalAlignment = Alignment.Top) {
                    Icon(
                        imageVector = when (finding.severity) {
                            VpnLeakDiagnostic.Severity.ERROR -> Icons.Default.Error
                            VpnLeakDiagnostic.Severity.WARNING -> Icons.Default.Warning
                            VpnLeakDiagnostic.Severity.INFO -> Icons.Default.CheckCircle
                        },
                        contentDescription = null,
                        tint = when (finding.severity) {
                            VpnLeakDiagnostic.Severity.ERROR -> Color(0xFFEF4444)
                            VpnLeakDiagnostic.Severity.WARNING -> Color(0xFFF59E0B)
                            VpnLeakDiagnostic.Severity.INFO -> Color(0xFF10B981)
                        },
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = finding.message,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF0F172A)
                            )
                            Text(
                                text = finding.category,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = Color(0xFF64748B)
                            )
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = finding.technicalDetails,
                            fontSize = 11.sp,
                            color = Color(0xFF475569)
                        )
                    }
                }
            }
        }

        // 5. Diagnostic & Auto-Fix Log Console Window
        item {
            Column {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Diagnostic & Auto-Fix Log Generator",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF0F172A)
                    )

                    IconButton(
                        onClick = {
                            val allLogs = diagnosticReport?.logLines?.joinToString("\n") ?: "No logs available"
                            val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                            clipboard.setPrimaryClip(ClipData.newPlainText("Diagnostic Logs", allLogs))
                            Toast.makeText(context, "Diagnostic logs copied to clipboard!", Toast.LENGTH_SHORT).show()
                        }
                    ) {
                        Icon(imageVector = Icons.Default.ContentCopy, contentDescription = "Copy Logs", tint = Color(0xFF0F62FE), modifier = Modifier.size(18.dp))
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                        .background(Color(0xFF0F172A))
                        .padding(14.dp)
                ) {
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        val lines = diagnosticReport?.logLines ?: listOf("No audit logs available. Click 'Run Audit'.")
                        lines.forEach { line ->
                            val textColor = when {
                                line.contains("[ERROR]") || line.contains("LEAK DETECTED") -> Color(0xFFF87171)
                                line.contains("[WARN]") -> Color(0xFFFBBF24)
                                line.contains("[OK]") || line.contains("ZERO-LEAK") -> Color(0xFF34D399)
                                else -> Color(0xFF94A3B8)
                            }
                            Text(
                                text = line,
                                fontSize = 10.5.sp,
                                fontFamily = FontFamily.Monospace,
                                color = textColor
                            )
                        }
                    }
                }
            }
        }
    }
}
