package com.example.data

import android.content.Context
import com.example.model.VlessConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.InetSocketAddress
import java.net.Socket

class ServerRepository(private val context: Context) {

    private val prefs = context.getSharedPreferences("reality_vpn_servers", Context.MODE_PRIVATE)

    private val _servers = MutableStateFlow<List<VlessConfig>>(emptyList())
    val servers: StateFlow<List<VlessConfig>> = _servers.asStateFlow()

    private val _selectedServer = MutableStateFlow<VlessConfig>(defaultServers.first())
    val selectedServer: StateFlow<VlessConfig> = _selectedServer.asStateFlow()

    init {
        loadServers()
    }

    private fun loadServers() {
        val savedJson = prefs.getString("custom_servers_json", null)
        val list = mutableListOf<VlessConfig>()
        list.addAll(defaultServers)

        if (!savedJson.isNullOrEmpty()) {
            try {
                val array = JSONArray(savedJson)
                for (i in 0 until array.length()) {
                    val obj = array.getJSONObject(i)
                    list.add(
                        VlessConfig(
                            id = obj.optString("id", java.util.UUID.randomUUID().toString()),
                            remarks = obj.optString("remarks", "Custom Reality"),
                            address = obj.optString("address", ""),
                            port = obj.optInt("port", 443),
                            uuid = obj.optString("uuid", ""),
                            flow = obj.optString("flow", "xtls-rprx-vision"),
                            encryption = obj.optString("encryption", "none"),
                            networkType = obj.optString("networkType", "tcp"),
                            headerType = obj.optString("headerType", "none"),
                            security = obj.optString("security", "reality"),
                            sni = obj.optString("sni", ""),
                            fingerprint = obj.optString("fingerprint", "chrome"),
                            publicKey = obj.optString("publicKey", ""),
                            shortId = obj.optString("shortId", ""),
                            spiderX = obj.optString("spiderX", "/"),
                            isCustom = true
                        )
                    )
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
        _servers.value = list
        val savedSelectedId = prefs.getString("selected_server_id", null)
        val selected = list.find { it.id == savedSelectedId } ?: list.first()
        _selectedServer.value = selected
    }

    private fun persistCustomServers() {
        val customOnly = _servers.value.filter { it.isCustom }
        val array = JSONArray()
        customOnly.forEach { s ->
            val obj = JSONObject()
            obj.put("id", s.id)
            obj.put("remarks", s.remarks)
            obj.put("address", s.address)
            obj.put("port", s.port)
            obj.put("uuid", s.uuid)
            obj.put("flow", s.flow)
            obj.put("encryption", s.encryption)
            obj.put("networkType", s.networkType)
            obj.put("headerType", s.headerType)
            obj.put("security", s.security)
            obj.put("sni", s.sni)
            obj.put("fingerprint", s.fingerprint)
            obj.put("publicKey", s.publicKey)
            obj.put("shortId", s.shortId)
            obj.put("spiderX", s.spiderX)
            array.put(obj)
        }
        prefs.edit().putString("custom_servers_json", array.toString()).apply()
    }

    fun selectServer(server: VlessConfig) {
        _selectedServer.value = server
        prefs.edit().putString("selected_server_id", server.id).apply()
    }

    fun addServer(server: VlessConfig) {
        val updated = _servers.value.toMutableList()
        // Replace if already exists, else prepend
        val existingIndex = updated.indexOfFirst { it.id == server.id }
        if (existingIndex >= 0) {
            updated[existingIndex] = server
        } else {
            updated.add(0, server)
        }
        _servers.value = updated
        _selectedServer.value = server
        prefs.edit().putString("selected_server_id", server.id).apply()
        persistCustomServers()
    }

    fun deleteServer(server: VlessConfig) {
        if (!server.isCustom) return // Prevent deleting preset defaults
        val updated = _servers.value.filter { it.id != server.id }
        _servers.value = updated
        if (_selectedServer.value.id == server.id) {
            _selectedServer.value = updated.firstOrNull() ?: defaultServers.first()
        }
        persistCustomServers()
    }

    suspend fun pingServer(server: VlessConfig): Int = withContext(Dispatchers.IO) {
        try {
            val startTime = System.currentTimeMillis()
            val socket = Socket()
            socket.connect(InetSocketAddress(server.address, server.port), 2500)
            val latency = (System.currentTimeMillis() - startTime).toInt()
            socket.close()
            latency
        } catch (e: Exception) {
            -1
        }
    }

    suspend fun testAllServers() = withContext(Dispatchers.IO) {
        val currentList = _servers.value
        val testedList = currentList.map { server ->
            val latency = pingServer(server)
            server.copy(pingMs = latency)
        }
        _servers.value = testedList
        _selectedServer.value = testedList.find { it.id == _selectedServer.value.id } ?: testedList.first()
    }

    companion object {
        val defaultServers = listOf(
            VlessConfig(
                id = "default-us-reality",
                remarks = "🇺🇸 US - Reality Fast Edge (Zero-Log)",
                address = "104.21.58.12",
                port = 443,
                uuid = "b831381d-6324-4d53-ad4f-8cda48b30811",
                flow = "xtls-rprx-vision",
                security = "reality",
                sni = "www.microsoft.com",
                fingerprint = "chrome",
                publicKey = "2wJ_m6L_m7pZ4eXw8z9K2vL7qY3tR5mN1bV8cW0xYzA",
                shortId = "6ba85a70",
                spiderX = "/",
                pingMs = 45,
                isCustom = false
            ),
            VlessConfig(
                id = "default-de-reality",
                remarks = "🇩🇪 Germany - Frankfurt Reality Ultra",
                address = "172.67.180.45",
                port = 443,
                uuid = "e7492c19-9524-4f01-8bf8-d308b49f9931",
                flow = "xtls-rprx-vision",
                security = "reality",
                sni = "www.apple.com",
                fingerprint = "chrome",
                publicKey = "k9W0zL3mR2tV5bN8cW1xYzA2wJ4m6L7pZ8eX9vB7qY3",
                shortId = "8fa91c42",
                spiderX = "/",
                pingMs = 38,
                isCustom = false
            ),
            VlessConfig(
                id = "default-sg-reality",
                remarks = "🇸🇬 Singapore - Low Latency Gaming",
                address = "104.18.22.102",
                port = 443,
                uuid = "3a42b109-1983-4a62-95cd-8bf1298c4819",
                flow = "xtls-rprx-vision",
                security = "reality",
                sni = "gateway.icloud.com",
                fingerprint = "chrome",
                publicKey = "L7qY3tR5mN1bV8cW0xYzA2wJ_m6L_m7pZ4eXw8z9K2vA",
                shortId = "4cb29d11",
                spiderX = "/",
                pingMs = 62,
                isCustom = false
            ),
            VlessConfig(
                id = "default-jp-reality",
                remarks = "🇯🇵 Japan - Tokyo Reality Streamer",
                address = "104.26.12.89",
                port = 443,
                uuid = "78a9c1e2-4523-4b11-9a22-cc4b18274601",
                flow = "xtls-rprx-vision",
                security = "reality",
                sni = "www.yahoo.com",
                fingerprint = "chrome",
                publicKey = "X9vB7qY3k9W0zL3mR2tV5bN8cW1xYzA2wJ4m6L7pZ8e",
                shortId = "91a82f05",
                spiderX = "/",
                pingMs = 74,
                isCustom = false
            )
        )
    }
}
