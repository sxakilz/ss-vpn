package com.example

import android.app.Application
import com.example.core.ConfigManager
import com.example.data.AppConfigManager

class RealityVpnApp : Application() {

    lateinit var appConfigManager: AppConfigManager
        private set

    lateinit var configManager: ConfigManager
        private set

    override fun onCreate() {
        super.onCreate()
        instance = this
        appConfigManager = AppConfigManager(this)
        configManager = ConfigManager(this)
    }

    companion object {
        lateinit var instance: RealityVpnApp
            private set
    }
}
